<?php
require_once 'config.php'; require_role('admin');
$yearLevels=['Grade 7','Grade 8','Grade 9','Grade 10','Senior High - Grade 11','Senior High - Grade 12'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $action=$_POST['action']??'';
 if($action==='save'){
  $id=(int)($_POST['id']??0); $student_id=trim($_POST['student_id']??''); $name=trim($_POST['full_name']??''); $year=trim($_POST['year_level']??''); $section=trim($_POST['section']??''); $email=trim($_POST['email']??''); $uidRaw=trim((string)($_POST['rfid_uid']??'')); $uid=strtoupper(preg_replace('/[^A-Fa-f0-9]/','',$uidRaw)); $status=($_POST['card_status']??'Active')==='Inactive'?'Inactive':'Active';
  if(!$student_id||strlen($student_id)>60||!$name||strlen($name)>150||!in_array($year,$yearLevels,true)
      ||strlen($section)>100||($email!==''&&(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>150))
      ||($uidRaw!==''&&(strlen($uid)<4||strlen($uid)>32))){
   $_SESSION['flash']='Check the student details, email, grade level, and RFID UID.';
  }else{
   $pdo=db();
   $pdo->beginTransaction();
   try{
    $previous=null;
    if($id){
     $find=$pdo->prepare('SELECT id,rfid_uid,card_status FROM students WHERE id=? FOR UPDATE');
     $find->execute([$id]);$previous=$find->fetch();
     if(!$previous){throw new RuntimeException('Student record was not found.');}
     $q=$pdo->prepare('UPDATE students SET student_id=?,full_name=?,course=?,year_level=?,section=?,email=?,rfid_uid=?,card_status=? WHERE id=?');
     $q->execute([$student_id,$name,'',$year,$section?:null,$email?:null,$uid?:null,$status,$id]);
    }else{
     $q=$pdo->prepare('INSERT INTO students(student_id,full_name,course,year_level,section,email,rfid_uid,card_status) VALUES(?,?,?,?,?,?,?,?)');
     $q->execute([$student_id,$name,'',$year,$section?:null,$email?:null,$uid?:null,$status]);
     $id=(int)$pdo->lastInsertId();
    }
    $previousUid=$previous ? (string)($previous['rfid_uid']??'') : '';
    if($previousUid!==$uid){
     if($previousUid!==''){
      $revoke=$pdo->prepare('UPDATE student_rfid_history SET revoked_at=NOW(),revoked_by=? WHERE student_id=? AND rfid_uid=? AND revoked_at IS NULL');
      $revoke->execute([(int)$_SESSION['admin_id'],$id,$previousUid]);
     }
     if($uid!==''){
      $history=$pdo->prepare('INSERT INTO student_rfid_history(student_id,rfid_uid,assigned_at,assigned_by) VALUES(?,?,NOW(),?)');
      $history->execute([$id,$uid,(int)$_SESSION['admin_id']]);
     }
      audit_event('rfid.replaced','student',$id,['previous_assignment'=>(bool)$previousUid,'new_assignment'=>(bool)$uid]);
    }
    audit_event($previous?'student.updated':'student.created','student',$id,['rfid_changed'=>$previousUid!==$uid]);
    $pdo->commit();
    $_SESSION['flash']='Student record saved successfully. Card assignment history was retained.';
   }catch(PDOException $e){
    if($pdo->inTransaction())$pdo->rollBack();
    $_SESSION['flash']=$e->getCode()==='23000'?'Student ID or RFID UID already exists.':'Database error while saving student.';
   }catch(RuntimeException $e){
    if($pdo->inTransaction())$pdo->rollBack();
    $_SESSION['flash']=$e->getMessage();
   }
  }
 }elseif($action==='deactivate'){
  $id=(int)($_POST['id']??0);$pdo=db();$pdo->beginTransaction();
  try{
   $find=$pdo->prepare('SELECT rfid_uid FROM students WHERE id=? FOR UPDATE');$find->execute([$id]);$record=$find->fetch();
   if($record){
    if(!empty($record['rfid_uid'])){
     $revoke=$pdo->prepare('UPDATE student_rfid_history SET revoked_at=NOW(),revoked_by=? WHERE student_id=? AND rfid_uid=? AND revoked_at IS NULL');
     $revoke->execute([(int)$_SESSION['admin_id'],$id,$record['rfid_uid']]);
    }
    $q=$pdo->prepare("UPDATE students SET rfid_uid=NULL,card_status='Inactive' WHERE id=?");$q->execute([$id]);
    audit_event('student.deactivated','student',$id,['rfid_revoked'=>!empty($record['rfid_uid'])]);
    $_SESSION['flash']='Student deactivated. The record and report history were retained.';
   }else{$_SESSION['flash']='Student record not found.';}
   $pdo->commit();
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
 }
 header('Location: students.php');exit;
}
$edit=null;if(isset($_GET['edit'])){$q=db()->prepare('SELECT * FROM students WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$totalStudents=(int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn();
$search=trim($_GET['q']??'');$activeCardsOnly=($_GET['active_cards']??'')==='1';$conditions=[];$params=[];if($activeCardsOnly){$conditions[]="card_status='Active' AND rfid_uid IS NOT NULL";}if($search!==''){$conditions[]='(student_id LIKE ? OR full_name LIKE ? OR rfid_uid LIKE ?)';$params[]="%$search%";$params[]="%$search%";$params[]="%$search%";}
$whereSql=$conditions?' WHERE '.implode(' AND ',$conditions):'';
$countQuery=db()->prepare('SELECT COUNT(*) FROM students'.$whereSql);$countQuery->execute($params);$filteredStudents=(int)$countQuery->fetchColumn();
$perPage=20;$requestedPage=filter_var($_GET['page']??1,FILTER_VALIDATE_INT);$currentPage=is_int($requestedPage)&&$requestedPage>0?$requestedPage:1;$totalPages=max(1,(int)ceil($filteredStudents/$perPage));$currentPage=min($currentPage,$totalPages);$offset=($currentPage-1)*$perPage;
$sql='SELECT * FROM students'.$whereSql.' ORDER BY full_name LIMIT '.$perPage.' OFFSET '.$offset;$q=db()->prepare($sql);$q->execute($params);$students=$q->fetchAll();
$paginationParams=[];if($search!==''){$paginationParams['q']=$search;}if($activeCardsOnly){$paginationParams['active_cards']='1';}$paginationUrl=static fn(int $page):string=>'students.php?'.http_build_query($paginationParams+['page'=>$page]);$rangeStart=$filteredStudents===0?0:$offset+1;$rangeEnd=min($offset+$perPage,$filteredStudents);
$flash=$_SESSION['flash']??'';unset($_SESSION['flash']);
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Students</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head><body><?php include 'nav.php'; ?><main class="container students-page">
<div class="page-head students-page-head"><div><span class="eyebrow">RECORD MANAGEMENT</span><h1>Students</h1></div><div class="stat students-total-stat"><span>Registered students</span><strong><?=$totalStudents?></strong></div></div><?php if($flash): ?><div class="notice"><?=h($flash)?></div><?php endif; ?>
<dialog class="student-modal" id="studentModal" aria-labelledby="studentModalTitle">
  <div class="student-modal-head">
    <h2 id="studentModalTitle"><?=$edit?'Edit student':'Register a student'?></h2>
    <button type="button" class="modal-close" id="closeStudentModal" aria-label="Close dialog"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
  </div>
  <form method="post" id="studentForm">
    <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?=h($edit['id']??'')?>">
    <div class="form-grid">
      <div><label for="student_id">Student ID *</label><input id="student_id" name="student_id" required value="<?=h($edit['student_id']??'')?>"></div>
      <div><label for="full_name">Full name *</label><input id="full_name" name="full_name" required value="<?=h($edit['full_name']??'')?>"></div>
      <div><label for="year_level">Grade level *</label><select id="year_level" name="year_level" required><option value="">Select grade level</option><?php foreach($yearLevels as $y): ?><option value="<?=h($y)?>" <?=($edit['year_level']??'')===$y?'selected':''?>><?=h($y)?></option><?php endforeach; ?></select></div>
      <div><label for="section">Section</label><input id="section" name="section" value="<?=h($edit['section']??'')?>"></div>
      <div><label for="email">Email</label><input id="email" type="email" name="email" maxlength="150" value="<?=h($edit['email']??'')?>"></div>
      <div><label for="card_status">Card status</label><select id="card_status" name="card_status"><option <?=($edit['card_status']??'Active')==='Active'?'selected':''?>>Active</option><option <?=($edit['card_status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></div>
    </div>
    <label for="rfid_uid">RFID UID</label>
    <div class="inline"><input id="rfid_uid" name="rfid_uid" placeholder="Scan a card or enter UID" value="<?=h($edit['rfid_uid']??'')?>"><button type="button" class="button secondary" id="scanBtn"><i class="fa-solid fa-id-card" aria-hidden="true"></i> Scan card</button></div>
    <p class="hint" id="scanStatus">Card scans are not kept as a history. Enrollment capture is armed for one card and expires after 30 seconds. Changing a UID revokes the old assignment but keeps student and report records. For a transfer, use <a href="reassign_card.php">Reassign card</a>.</p>
    <div class="actions"><button type="submit"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Save student</button><button type="button" class="button secondary" id="cancelStudentModal">Cancel</button></div>
  </form>
</dialog>
<section class="panel"><div class="section-head"><div class="table-toolbar"><form class="search" method="get"><?php if($activeCardsOnly): ?><input type="hidden" name="active_cards" value="1"><?php endif; ?><input name="q" placeholder="Search ID, name, UID..." value="<?=h($search)?>"><button class="button secondary" type="submit" title="Search" aria-label="Search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></button><?php if($activeCardsOnly): ?><a class="button secondary" href="students.php">All students</a><?php endif; ?></form><div class="actions"><a class="button secondary" href="reassign_card.php">Reassign card</a><button type="button" class="button" id="addStudentBtn"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Add student</button></div></div></div><div class="table-wrap"><table><thead><tr><th>Student ID</th><th>Name</th><th>Grade level</th><th>RFID UID</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach($students as $s): ?><tr><td><?=h($s['student_id'])?></td><td><?=h($s['full_name'])?></td><td><?=h($s['year_level'])?></td><td><code><?=h($s['rfid_uid']?:'—')?></code></td><td><span class="pill <?=$s['card_status']==='Active'?'green':'gray'?>"><?=h($s['card_status'])?></span></td><td class="actions-cell"><a href="?<?=h(http_build_query($paginationParams+['edit'=>$s['id'],'page'=>$currentPage]))?>">Edit</a><?php if($s['card_status']==='Active'): ?><form method="post" onsubmit="return confirm('Deactivate this student? The record and report history will be retained, and any active card will be revoked.')"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="deactivate"><input type="hidden" name="id" value="<?=$s['id']?>"><button class="link danger" type="submit">Deactivate</button></form><?php endif; ?></td></tr><?php endforeach; ?><?php if(!$students): ?><tr><td colspan="6" class="empty">No matching students.</td></tr><?php endif; ?></tbody></table></div>
<nav class="pagination students-pagination" aria-label="Student pages">
  <span class="pagination-summary">Showing <?=$rangeStart?>–<?=$rangeEnd?> of <?=$filteredStudents?></span>
  <div class="pagination-links">
    <?php if($currentPage>1): ?><a href="<?=h($paginationUrl($currentPage-1))?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</a><?php else: ?><span class="disabled"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</span><?php endif; ?>
    <?php
      $firstPage=max(1,$currentPage-2);
      $lastPage=min($totalPages,$currentPage+2);
      if($firstPage>1): ?><a href="<?=h($paginationUrl(1))?>">1</a><?php if($firstPage>2): ?><span class="pagination-ellipsis">…</span><?php endif; ?><?php endif;
      for($pageNumber=$firstPage;$pageNumber<=$lastPage;$pageNumber++):
        if($pageNumber===$currentPage): ?><span class="current" aria-current="page"><?=$pageNumber?></span><?php else: ?><a href="<?=h($paginationUrl($pageNumber))?>"><?=$pageNumber?></a><?php endif;
      endfor;
      if($lastPage<$totalPages): if($lastPage<$totalPages-1): ?><span class="pagination-ellipsis">…</span><?php endif; ?><a href="<?=h($paginationUrl($totalPages))?>"><?=$totalPages?></a><?php endif;
    ?>
    <?php if($currentPage<$totalPages): ?><a href="<?=h($paginationUrl($currentPage+1))?>" aria-label="Next page">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a><?php else: ?><span class="disabled">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></span><?php endif; ?>
  </div>
</nav></section></main>
<script>
const studentModal=document.getElementById('studentModal');
let scanTimer=null,lastScanId=0,scanCaptureDeadline=0;
const originalUid=<?=json_encode((string)($edit['rfid_uid']??''))?>;
document.getElementById('studentForm').addEventListener('submit',event=>{
 const nextUid=document.getElementById('rfid_uid').value.trim().toUpperCase().replace(/[^A-F0-9]/g,'');
 if(originalUid!==nextUid&&!confirm('This changes the RFID assignment. The previous card will stop working for this student; existing student and report records are retained. Continue?')){
  event.preventDefault();
 }
});
document.getElementById('addStudentBtn').addEventListener('click',()=>studentModal.showModal());
document.getElementById('closeStudentModal').addEventListener('click',()=>studentModal.close());
document.getElementById('cancelStudentModal').addEventListener('click',()=>studentModal.close());
studentModal.addEventListener('click',event=>{
 if(event.target===studentModal) studentModal.close();
});
studentModal.addEventListener('close',()=>{
 clearTimeout(scanTimer);
 scanTimer=null;
 scanCaptureDeadline=0;
 document.getElementById('scanBtn').disabled=false;
});
<?php if($edit): ?>studentModal.showModal();<?php endif; ?>
document.getElementById('scanBtn').addEventListener('click',()=>{
 const status=document.getElementById('scanStatus'); status.textContent='Waiting for a card... tap it on the PN532 reader.';
 document.getElementById('scanBtn').disabled=true;
 const form=new URLSearchParams({csrf:<?=json_encode(csrf_token())?>});
 fetch('api/arm_scan.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form.toString(),cache:'no-store'})
  .then(async r=>{const d=await r.json();if(!r.ok||!d.success)throw new Error(d.message||'Could not start card capture.');return d;})
  .then(d=>{lastScanId=d.scan_id||0;scanCaptureDeadline=Date.now()+30000;pollScan();})
  .catch(error=>{status.textContent=error.message||'Could not contact server.';document.getElementById('scanBtn').disabled=false;});
});
function pollScan(){
 if(!studentModal.open) return;
 const status=document.getElementById('scanStatus');
 if(Date.now()>=scanCaptureDeadline){
  status.textContent='Card capture expired. Click “Scan card” to try again.';
  document.getElementById('scanBtn').disabled=false;
  return;
 }
 fetch('api/latest_scan.php?after='+lastScanId,{cache:'no-store'}).then(r=>r.json()).then(d=>{
  if(d.success && d.scan_id>lastScanId){document.getElementById('rfid_uid').value=d.uid;status.textContent='Card detected: '+d.uid;document.getElementById('scanBtn').disabled=false;return;}
  scanTimer=setTimeout(pollScan,1000);
 }).catch(()=>{status.textContent='Connection error. Check website and ESP32.';document.getElementById('scanBtn').disabled=false;});
}
</script></body></html>