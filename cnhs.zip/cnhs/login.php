<?php
require_once 'config.php';
$error = '';
$lockSecondsRemaining = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pdo = db();
    $ipHash = hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '');
    $pdo->exec(
        'DELETE FROM admin_login_attempts
         WHERE last_attempt_at < DATE_SUB(NOW(), INTERVAL 1 DAY)'
    );

    $pdo->beginTransaction();
    try {
        $insert = $pdo->prepare(
            'INSERT IGNORE INTO admin_login_attempts (ip_hash) VALUES (?)'
        );
        $insert->execute([$ipHash]);

        $attemptStmt = $pdo->prepare(
            'SELECT failed_attempts, last_attempt_at, locked_until,
                    TIMESTAMPDIFF(SECOND, last_attempt_at, NOW()) AS seconds_since_attempt,
                    (locked_until IS NOT NULL AND locked_until <= NOW()) AS lock_expired,
                    TIMESTAMPDIFF(SECOND, NOW(), locked_until) AS lock_seconds
             FROM admin_login_attempts
             WHERE ip_hash = ?
             FOR UPDATE'
        );
        $attemptStmt->execute([$ipHash]);
        $attempt = $attemptStmt->fetch();

        if ((int)$attempt['lock_seconds'] > 0) {
            $pdo->commit();
            $lockSecondsRemaining = (int)$attempt['lock_seconds'];
            $error = 'Too many failed attempts. Try again in ';
        } else {
            $stmt = $pdo->prepare('SELECT id, username, password_hash, role, is_active FROM admins WHERE username=?');
            $stmt->execute([trim($_POST['username'] ?? '')]);
            $admin = $stmt->fetch();

            if ($admin && (bool)$admin['is_active'] && password_verify($_POST['password'] ?? '', $admin['password_hash'])) {
                $delete = $pdo->prepare('DELETE FROM admin_login_attempts WHERE ip_hash = ?');
                $delete->execute([$ipHash]);
                $pdo->commit();

                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_role'] = $admin['role'];
                header('Location: dashboard.php');
                exit;
            }

            $withinWindow = $attempt['last_attempt_at'] !== null
                && (int)$attempt['seconds_since_attempt'] < 180
                && !(bool)$attempt['lock_expired'];
            $failedAttempts = $withinWindow ? (int)$attempt['failed_attempts'] + 1 : 1;
            $update = $pdo->prepare(
                'UPDATE admin_login_attempts
                 SET failed_attempts = ?, last_attempt_at = NOW(),
                     locked_until = IF(? >= 3, DATE_ADD(NOW(), INTERVAL 3 MINUTE), NULL)
                 WHERE ip_hash = ?'
            );
            $update->execute([$failedAttempts, $failedAttempts, $ipHash]);
            $pdo->commit();

            $error = $failedAttempts >= 3
                ? 'Too many failed attempts. Try again in '
                : 'Incorrect username or password.';
            if ($failedAttempts >= 3) {
                $lockSecondsRemaining = 180;
            }
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $exception;
    }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Staff Login</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth"><form class="panel auth-panel" method="post"><img class="brand-logo large" src="assets/CNHS.png" alt="Carranglan National High School seal"><h1>CNHS REPORTING</h1><p>Staff access for student reporting</p><?php if($error): ?><div class="error"><?=h($error)?><?php if($lockSecondsRemaining !== null): ?><span id="lock-countdown"><?=h($lockSecondsRemaining)?></span> <span id="lock-countdown-unit">seconds</span>.</div><?php else: ?></div><?php endif; ?><?php endif; ?><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Username</label><input name="username" required autocomplete="username"><label>Password</label><input type="password" name="password" required autocomplete="current-password"><button>Sign in</button></form><?php if($lockSecondsRemaining !== null): ?><script>
let secondsLeft = <?=json_encode($lockSecondsRemaining)?>;
const countdown = document.getElementById('lock-countdown');
const countdownUnit = document.getElementById('lock-countdown-unit');
const updateCountdown = () => {
    countdown.textContent = secondsLeft;
    countdownUnit.textContent = secondsLeft === 1 ? 'second' : 'seconds';
    if (secondsLeft > 0) {
        secondsLeft -= 1;
        window.setTimeout(updateCountdown, 1000);
    } else {
        countdown.parentElement.textContent = 'You can try signing in again now.';
    }
};
updateCountdown();
</script><?php endif; ?><p class="hint"><a href="student_login.php">Student portal sign in</a> · <a href="student_register.php">Create a student account</a></p></body></html>