<?php
require_once 'config.php';
unset($_SESSION['student_account_id'], $_SESSION['student_ref'], $_SESSION['student_rfid_uid']);
session_regenerate_id(true);
header('Location: student_login.php');
exit;
