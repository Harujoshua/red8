<?php
require_once 'config.php';
require_role('admin');

$perPage = 50;
$requestedPage = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$page = is_int($requestedPage) && $requestedPage > 0 ? $requestedPage : 1;
audit_event('audit.viewed', 'audit_log', null, ['page' => $page]);
$total = (int)db()->query('SELECT COUNT(*) FROM audit_log')->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;
$stmt = db()->prepare(
    'SELECT actor_username, action, entity_type, entity_id, details, created_at
     FROM audit_log ORDER BY id DESC LIMIT ? OFFSET ?'
);
$stmt->bindValue(1, $perPage, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$events = $stmt->fetchAll();
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Audit log</title><link rel="stylesheet" href="assets/style.css"></head>
<body><?php include 'nav.php'; ?><main class="container">
  <div class="page-head"><div><span class="eyebrow">ACCOUNTABILITY</span><h1>Audit log</h1><p>Administrative record of report access and system changes.</p></div></div>
  <section class="panel"><div class="table-wrap"><table>
    <thead><tr><th>Date / time</th><th>Staff</th><th>Action</th><th>Record</th><th>Details</th></tr></thead>
    <tbody><?php foreach ($events as $event):
      $details = $event['details'] === null ? null : json_decode($event['details'], true);
      $detailsText = is_array($details)
          ? json_encode($details, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
          : (string)($event['details'] ?? '');
    ?><tr>
      <td><?=h($event['created_at'])?></td>
      <td><?=h($event['actor_username'])?></td>
      <td><?=h($event['action'])?></td>
      <td><?=h($event['entity_type'])?><?= $event['entity_id'] !== null ? ' #'.h($event['entity_id']) : '' ?></td>
      <td><code><?=h($detailsText ?: '—')?></code></td>
    </tr><?php endforeach; ?>
    <?php if (!$events): ?><tr><td colspan="5" class="empty">No audit entries yet.</td></tr><?php endif; ?></tbody>
  </table></div>
  <nav class="pagination" aria-label="Audit pages">
    <span class="pagination-summary">Showing <?=$total===0?0:$offset+1?>–<?=min($offset+$perPage,$total)?> of <?=$total?></span>
    <div class="pagination-links">
      <?php if ($page > 1): ?><a href="?page=<?=$page-1?>">Previous</a><?php else: ?><span class="disabled">Previous</span><?php endif; ?>
      <span class="current" aria-current="page"><?=$page?> / <?=$pages?></span>
      <?php if ($page < $pages): ?><a href="?page=<?=$page+1?>">Next</a><?php else: ?><span class="disabled">Next</span><?php endif; ?>
    </div>
  </nav></section>
</main></body></html>
