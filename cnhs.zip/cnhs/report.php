<?php
require_once 'config.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');

$status = null;
$error = '';
$referenceInput = $_POST['reference'] ?? '';
$reference = is_string($referenceInput) ? trim($referenceInput) : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tokenInput = $_POST['tracking_token'] ?? '';
    $token = is_string($tokenInput) ? strtolower(trim($tokenInput)) : '';
    if (!preg_match('/\ACNHS-\d{8}-\d{6}\z/D', $reference)
        || !preg_match('/\A[a-f0-9]{32}\z/D', $token)) {
        $error = 'Reference or follow-up code not recognized.';
    } else {
        $stmt = db()->prepare(
            'SELECT status FROM reports
             WHERE reference = ? AND tracking_token_hash = ? LIMIT 1'
        );
        $stmt->execute([$reference, hash('sha256', $token)]);
        $status = $stmt->fetchColumn();
        if ($status === false) {
            $error = 'Reference or follow-up code not recognized.';
        }
    }
}
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Concern Tracking Portal</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth">
  <main class="panel auth-panel">
    <img class="brand-logo large" src="assets/CNHS.png" alt="Carranglan National High School seal">
    <span class="eyebrow">STUDENT PORTAL</span>
    <h1>Track your concern</h1>
    <p>Use your report reference and private follow-up code to securely check the latest progress on a concern you submitted.</p>
    <?php if ($error): ?><div class="error" role="alert"><?=h($error)?></div><?php endif; ?>
    <?php if ($status !== null): ?>
      <div class="notice" role="status" aria-live="polite">
        <strong>Report <?=h($reference)?></strong>
        <p><strong>Current status: <?=h((string)$status)?></strong></p>
        <p><?=h(report_status_description((string)$status))?></p>
      </div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
      <label for="reference">Reference number</label>
      <input id="reference" name="reference" required maxlength="24" value="<?=h($reference)?>" autocomplete="off">
      <label for="tracking_token">Private follow-up code</label>
      <input id="tracking_token" name="tracking_token" required minlength="32" maxlength="32" pattern="[a-fA-F0-9]{32}" autocomplete="off" spellcheck="false">
      <button type="submit">Track concern</button>
    </form>
    <p class="hint">Your follow-up code is private. Keep it safe and do not share it. This portal only displays the status; it does not reveal report details or student identity.</p>
    <p class="hint"><a href="student_login.php">Sign in to your student portal</a> · <a href="student_register.php">Register a student account</a></p>
  </main>
</body>
</html>
