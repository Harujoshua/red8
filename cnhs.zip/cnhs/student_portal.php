<?php
require_once 'config.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
$student = require_student_login();

$reportsQuery = db()->prepare(
    'SELECT reference, category, incident_detail, incident_date, location,
            priority, status, created_at
     FROM reports
     WHERE student_ref = ? AND reporting_method = \'Identified\'
     ORDER BY created_at DESC'
);
$reportsQuery->execute([(int)$student['student_ref']]);
$reports = $reportsQuery->fetchAll();
$openCount = count(array_filter(
    $reports,
    static fn(array $report): bool => !in_array($report['status'], ['Resolved', 'Closed'], true)
));
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>My Reported Concerns</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'student_nav.php'; ?>
<main class="container student-portal-page">
  <div class="page-head">
    <div><span class="eyebrow">STUDENT PORTAL</span><h1>My reported concerns</h1><p><?=h($student['full_name'])?> · <?=h($student['student_id'])?></p></div>
  </div>
  <div class="stats student-portal-stats">
    <div class="stat"><span>Total concerns</span><strong><?=count($reports)?></strong></div>
    <div class="stat"><span>Still in progress</span><strong><?=$openCount?></strong></div>
    <div class="stat"><span>Resolved or closed</span><strong><?=count($reports)-$openCount?></strong></div>
  </div>
  <section class="panel">
    <div class="section-head"><h2>Concern updates</h2><span class="hint">Only identified reports linked to your student record are shown.</span></div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Reference</th><th>Concern</th><th>Incident</th><th>Location</th><th>Priority</th><th>Status</th><th>Submitted</th></tr></thead>
        <tbody>
        <?php foreach ($reports as $report): ?>
          <tr>
            <td><code><?=h($report['reference'])?></code></td>
            <td><?=h($report['category'])?><small class="report-subdetail"><?=h($report['incident_detail'])?></small></td>
            <td><?=h($report['incident_date'])?></td>
            <td><?=h($report['location'])?></td>
            <td><span class="pill <?=$report['priority']==='High'?'red':'blue'?>"><?=$report['priority']==='High'?'Urgent':'Normal'?></span></td>
            <td><span class="pill <?=in_array($report['status'], ['Resolved', 'Closed'], true)?'green':'blue'?>"><?=h($report['status'])?></span><small class="report-subdetail"><?=h(report_status_description((string)$report['status']))?></small></td>
            <td><?=h($report['created_at'])?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$reports): ?><tr><td colspan="7" class="empty">No identified concerns are linked to your student record yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
  <p class="hint">If a concern you reported is missing or you need help, contact the school office. Anonymous concerns cannot be linked to a student account.</p>
</main>
</body>
</html>
