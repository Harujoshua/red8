<?php
require_once 'config.php';
require_role('admin');

$flash = (string)($_SESSION['student_accounts_flash'] ?? '');
unset($_SESSION['student_accounts_flash']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if (!in_array($action, ['approve', 'reject'], true)) {
        http_response_code(400);
        exit('Invalid account review action.');
    }
    $submittedIds = $_POST['account_ids'] ?? [];
    $ids = [];
    if (is_array($submittedIds)) {
        foreach ($submittedIds as $value) {
            if (is_string($value) && ctype_digit($value) && (int)$value > 0) {
                $ids[] = (int)$value;
            }
        }
    }
    $ids = array_values(array_unique($ids));
    if (!$ids) {
        $flash = 'Select at least one pending account to approve.';
    } else {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $eligible = $pdo->prepare(
                "SELECT a.id, a.student_ref
                 FROM student_portal_accounts a
                 " . ($action === 'approve'
                     ? 'JOIN students s ON s.id = a.student_ref JOIN issued_rfid_uids u ON u.uid = a.verified_rfid_uid'
                     : '') . "
                 WHERE a.id IN ($placeholders) AND a.status = 'Pending'"
                    . ($action === 'approve'
                        ? " AND s.card_status = 'Active'"
                        : '') . "
                 FOR UPDATE"
            );
            $eligible->execute($ids);
            $accounts = $eligible->fetchAll();
            if ($accounts) {
                $eligibleIds = array_map(static fn(array $account): int => (int)$account['id'], $accounts);
                $updatePlaceholders = implode(',', array_fill(0, count($eligibleIds), '?'));
                $approve = $pdo->prepare(
                    "UPDATE student_portal_accounts
                     SET status = ?, reviewed_at = NOW(), reviewed_by = ?
                     WHERE id IN ($updatePlaceholders) AND status = 'Pending'"
                );
                $newStatus = $action === 'approve' ? 'Approved' : 'Rejected';
                $approve->execute(array_merge([$newStatus, (int)$_SESSION['admin_id']], $eligibleIds));
                foreach ($accounts as $account) {
                    audit_event(
                        $action === 'approve' ? 'student.account_approved' : 'student.account_rejected',
                        'student_account',
                        (int)$account['id'],
                        [
                        'student_ref' => (int)$account['student_ref'],
                        ]
                    );
                }
            }
            $pdo->commit();
            $verb = $action === 'approve' ? 'approved' : 'rejected';
            $flash = count($accounts) . ' account' . (count($accounts) === 1 ? '' : 's') . ' ' . $verb . '.';
            if ($action === 'approve' && count($accounts) < count($ids)) {
                $flash .= ' Some selected requests were no longer pending or their card assignment changed; those were not approved.';
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }
    $_SESSION['student_accounts_flash'] = $flash;
    header('Location: student_accounts.php');
    exit;
}

$pendingCount = (int)db()->query(
    "SELECT COUNT(*) FROM student_portal_accounts WHERE status = 'Pending'"
)->fetchColumn();
$requests = db()->query(
    "SELECT a.id, a.student_ref, a.verified_rfid_uid, a.requested_at,
            s.student_id, s.full_name, s.year_level, s.section,
            u.uid AS allowed_uid, s.card_status
     FROM student_portal_accounts a
     JOIN students s ON s.id = a.student_ref
     LEFT JOIN issued_rfid_uids u ON u.uid = a.verified_rfid_uid
     WHERE a.status = 'Pending'
     ORDER BY a.requested_at ASC"
)->fetchAll();
$eligibleCount = count(array_filter(
    $requests,
    static fn(array $request): bool => $request['card_status'] === 'Active'
        && $request['allowed_uid'] === $request['verified_rfid_uid']
));
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Account Approvals</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'nav.php'; ?>
<main class="container account-approvals-page">
  <div class="page-head"><div><span class="eyebrow">STUDENT ACCESS</span><h1>Account approvals</h1><p>Review requests for active students using UIDs on the shared issued list.</p></div><div class="stat"><span>Pending requests</span><strong><?=$pendingCount?></strong></div></div>
  <?php if ($flash): ?><div class="notice" role="status"><?=h($flash)?></div><?php endif; ?>
  <section class="panel">
    <form method="post" id="approvalForm">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <div class="section-head">
        <h2>Pending registrations</h2>
        <div class="actions">
          <button type="submit" class="button" name="action" value="approve" <?=$eligibleCount>0?'':'disabled'?>><i class="fa-solid fa-user-check" aria-hidden="true"></i> Approve selected</button>
          <button type="submit" class="button secondary" name="action" value="reject" <?=$requests?'':'disabled'?>>Reject selected</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th><label class="sr-only" for="selectAllAccounts">Select all</label><input id="selectAllAccounts" type="checkbox" class="table-checkbox"></th><th>Student ID</th><th>Name</th><th>Grade / Section</th><th>Card UID check</th><th>Requested</th></tr></thead>
          <tbody>
          <?php foreach ($requests as $request): ?>
            <tr>
              <td><input type="checkbox" class="account-checkbox table-checkbox" name="account_ids[]" value="<?=(int)$request['id']?>" aria-label="Select <?=h($request['student_id'])?> account"></td>
              <td><?=h($request['student_id'])?></td>
              <td><?=h($request['full_name'])?></td>
              <td><?=h($request['year_level'])?><?=!empty($request['section'])?' · '.h($request['section']):''?></td>
              <td>
                <?php if ($request['card_status'] === 'Active' && $request['allowed_uid'] === $request['verified_rfid_uid']): ?>
                  <span class="pill green">On issued list</span><small class="report-subdetail"><code><?=h($request['verified_rfid_uid'])?></code></small>
                <?php else: ?>
                  <span class="pill red">UID not allowed</span><small class="report-subdetail">Add this UID to Issued UIDs or reject this request.</small>
                <?php endif; ?>
              </td>
              <td><?=h($request['requested_at'])?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$requests): ?><tr><td colspan="6" class="empty">There are no pending student account requests.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </form>
  </section>
</main>
<script>
const selectAllAccounts=document.getElementById('selectAllAccounts');
selectAllAccounts.addEventListener('change',()=>{
 document.querySelectorAll('.account-checkbox:not(:disabled)').forEach(checkbox=>checkbox.checked=selectAllAccounts.checked);
});
document.querySelectorAll('.account-checkbox:not(:disabled)').forEach(checkbox=>{
 checkbox.addEventListener('change',()=>{
  selectAllAccounts.checked=[...document.querySelectorAll('.account-checkbox:not(:disabled)')].every(item=>item.checked);
 });
});
document.getElementById('approvalForm').addEventListener('submit',event=>{
 if(!document.querySelector('.account-checkbox:checked')){
  event.preventDefault();
  window.alert('Select at least one account to approve.');
 }
});
</script>
</body>
</html>
