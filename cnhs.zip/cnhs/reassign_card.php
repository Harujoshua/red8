<?php
require_once 'config.php';
require_role('admin');

$error = '';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fromId = filter_var($_POST['from_student'] ?? null, FILTER_VALIDATE_INT);
    $toId = filter_var($_POST['to_student'] ?? null, FILTER_VALIDATE_INT);
    if ($fromId === false || $toId === false || $fromId === null || $toId === null
        || $fromId < 1 || $toId < 1 || $fromId === $toId) {
        $error = 'Choose two different student records.';
    } else {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $find = $pdo->prepare('SELECT id, student_id, full_name, rfid_uid FROM students WHERE id = ? FOR UPDATE');
            $find->execute([$fromId]);
            $from = $find->fetch();
            $find->execute([$toId]);
            $to = $find->fetch();
            if (!$from || !$to) {
                throw new RuntimeException('One of the selected student records no longer exists.');
            }
            if (empty($from['rfid_uid'])) {
                throw new RuntimeException('The source student does not have an assigned card.');
            }
            if (!empty($to['rfid_uid'])) {
                throw new RuntimeException('The destination student already has a card. Replace or clear that assignment first.');
            }

            $revoke = $pdo->prepare(
                'UPDATE student_rfid_history
                 SET revoked_at = NOW(), revoked_by = ?
                 WHERE student_id = ? AND rfid_uid = ? AND revoked_at IS NULL'
            );
            $revoke->execute([(int)$_SESSION['admin_id'], $fromId, $from['rfid_uid']]);
            if ($revoke->rowCount() !== 1) {
                throw new RuntimeException('The card assignment history is inconsistent. No changes were made.');
            }

            $remove = $pdo->prepare('UPDATE students SET rfid_uid = NULL WHERE id = ?');
            $remove->execute([$fromId]);
            $assign = $pdo->prepare("UPDATE students SET rfid_uid = ?, card_status = 'Active' WHERE id = ?");
            $assign->execute([$from['rfid_uid'], $toId]);
            $history = $pdo->prepare(
                'INSERT INTO student_rfid_history (student_id, rfid_uid, assigned_at, assigned_by)
                 VALUES (?, ?, NOW(), ?)'
            );
            $history->execute([$toId, $from['rfid_uid'], (int)$_SESSION['admin_id']]);
            audit_event('rfid.reassigned_from', 'student', $fromId, ['to_student_id' => $toId]);
            audit_event('rfid.reassigned_to', 'student', $toId, ['from_student_id' => $fromId]);
            $pdo->commit();
            $message = 'Card reassigned. Both student records and the card assignment history were retained.';
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $exception->getMessage();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }
}

$withCard = db()->query(
    "SELECT id, student_id, full_name FROM students WHERE rfid_uid IS NOT NULL AND rfid_uid <> '' ORDER BY full_name"
)->fetchAll();
$withoutCard = db()->query(
    "SELECT id, student_id, full_name FROM students WHERE (rfid_uid IS NULL OR rfid_uid = '') AND card_status = 'Active' ORDER BY full_name"
)->fetchAll();
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reassign RFID card</title><link rel="stylesheet" href="assets/style.css"></head>
<body><?php include 'nav.php'; ?><main class="container">
  <div class="page-head"><div><span class="eyebrow">CARD MANAGEMENT</span><h1>Reassign RFID card</h1><p>Move a card from one student to another without deleting either record or losing history.</p></div><a class="button secondary" href="students.php">Back to students</a></div>
  <?php if ($message): ?><div class="notice" role="status"><?=h($message)?></div><?php endif; ?>
  <?php if ($error): ?><div class="error" role="alert"><?=h($error)?></div><?php endif; ?>
  <section class="panel">
    <p>The destination student must not already have a card. To replace a lost card, edit the student and scan the new card; clearing the UID revokes the old assignment.</p>
    <form method="post">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <label for="from_student">Student whose card is being moved</label>
      <select id="from_student" name="from_student" required>
        <option value="">Select current card holder</option>
        <?php foreach ($withCard as $student): ?><option value="<?=(int)$student['id']?>"><?=h($student['student_id'].' — '.$student['full_name'])?></option><?php endforeach; ?>
      </select>
      <label for="to_student">Student receiving the card</label>
      <select id="to_student" name="to_student" required>
        <option value="">Select student without a card</option>
        <?php foreach ($withoutCard as $student): ?><option value="<?=(int)$student['id']?>"><?=h($student['student_id'].' — '.$student['full_name'])?></option><?php endforeach; ?>
      </select>
      <div class="actions"><button type="submit" <?=(!$withCard||!$withoutCard)?'disabled':''?>>Reassign card</button></div>
    </form>
  </section>
</main></body></html>
