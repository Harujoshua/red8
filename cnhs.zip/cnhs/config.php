<?php
declare(strict_types=1);
session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'cnhs_rfid');
define('DB_USER', 'root');
define('DB_PASS', ''); // Set your MySQL password here.
define('APP_NAME', 'CNHS Student Reporting System');
define('ESP32_API_KEY', '01d0eb2aa84b4be05f6b2d733de8975d3cfc7407028dec4f78d3fc8ea483a7ed');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'villanuevajoshua745@gmail.com');
define('MAIL_PASSWORD', 'sdnc jvot zdre psdc');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM', 'villanuevajoshua745@gmail.com');
define('MAIL_FROM_NAME', 'CNHS Student Reporting System');

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
        ensure_admin_email_column($pdo);
        ensure_admin_login_attempts_table($pdo);
        ensure_reports_status_column($pdo);
        ensure_admin_access_columns($pdo);
        ensure_report_tracking_column($pdo);
        ensure_student_portal_accounts_table($pdo);
        ensure_issued_rfid_uids_table($pdo);
        ensure_audit_log_table($pdo);
        purge_legacy_scan_events($pdo);
        ensure_rfid_history_table($pdo);
    }
    return $pdo;
}
function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function ensure_admin_login_attempts_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS admin_login_attempts (
            ip_hash CHAR(64) NOT NULL PRIMARY KEY,
            failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            last_attempt_at DATETIME DEFAULT NULL,
            locked_until DATETIME DEFAULT NULL,
            INDEX idx_admin_login_attempts_last_attempt (last_attempt_at)
        ) ENGINE=InnoDB'
    );
}
function ensure_admin_email_column(PDO $pdo): void {
    $stmt=$pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = \'admins\'
           AND COLUMN_NAME = \'email\''
    );
    $stmt->execute();
    if(!(bool)$stmt->fetchColumn()){
        $pdo->exec('ALTER TABLE admins ADD COLUMN email VARCHAR(150) DEFAULT NULL AFTER username');
    }
}
function ensure_reports_status_column(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS system_migrations (
            migration_key VARCHAR(100) NOT NULL PRIMARY KEY,
            applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB'
    );
    $stmt = $pdo->prepare(
        'SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, COLUMN_DEFAULT
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = \'reports\'
           AND COLUMN_NAME = \'status\''
    );
    $stmt->execute();
    $column = $stmt->fetch();
    if (!$column) {
        $pdo->exec("ALTER TABLE reports ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'Submitted' AFTER priority");
    } elseif ($column['DATA_TYPE'] !== 'varchar'
        || (int)$column['CHARACTER_MAXIMUM_LENGTH'] < 32
        || $column['COLUMN_DEFAULT'] !== 'Submitted') {
        $pdo->exec("ALTER TABLE reports MODIFY status VARCHAR(32) NOT NULL DEFAULT 'Submitted'");
    }
    $migration = $pdo->prepare(
        'INSERT IGNORE INTO system_migrations (migration_key) VALUES (?)'
    );
    $migration->execute(['expand_report_status_workflow_v1']);
    if ($migration->rowCount() === 1) {
        $pdo->exec("UPDATE reports SET status = 'Resolved' WHERE status = 'Done'");
    }
}
function report_statuses(): array {
    return [
        'Submitted',
        'Pending',
        'UnderReview',
        'Scheduled',
        'Ongoing',
        'ForFollow-up',
        'Resolved',
        'Closed',
    ];
}
function report_status_description(string $status): string {
    return [
        'Submitted' => 'Your report was received.',
        'Pending' => 'Your report is waiting to be reviewed.',
        'UnderReview' => 'A staff member is reviewing your report.',
        'Scheduled' => 'A follow-up has been scheduled.',
        'Ongoing' => 'Your report is being addressed.',
        'ForFollow-up' => 'Your report needs additional follow-up.',
        'Resolved' => 'The concern has been addressed.',
        'Closed' => 'The report has been closed.',
    ][$status] ?? 'Your report status is being updated.';
}
function ensure_admin_access_columns(PDO $pdo): void {
    foreach ([
        'role' => "ALTER TABLE admins ADD COLUMN role ENUM('admin','counselor') NOT NULL DEFAULT 'admin' AFTER password_hash",
        'is_active' => 'ALTER TABLE admins ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role',
    ] as $column => $alter) {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'admins\' AND COLUMN_NAME = ?'
        );
        $stmt->execute([$column]);
        if (!(bool)$stmt->fetchColumn()) {
            $pdo->exec($alter);
        }
    }
}
function ensure_report_tracking_column(PDO $pdo): void {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'reports\' AND COLUMN_NAME = \'tracking_token_hash\''
    );
    $stmt->execute();
    if (!(bool)$stmt->fetchColumn()) {
        $pdo->exec('ALTER TABLE reports ADD COLUMN tracking_token_hash CHAR(64) DEFAULT NULL AFTER submission_token');
    }
    $index = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'reports\' AND INDEX_NAME = \'uq_reports_tracking_token_hash\''
    );
    $index->execute();
    if (!(bool)$index->fetchColumn()) {
        $pdo->exec('ALTER TABLE reports ADD UNIQUE INDEX uq_reports_tracking_token_hash (tracking_token_hash)');
    }
}
function ensure_student_portal_accounts_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS student_portal_accounts (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            student_ref INT NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            verified_rfid_uid VARCHAR(32) NOT NULL,
            status ENUM(\'Pending\', \'Approved\', \'Rejected\') NOT NULL DEFAULT \'Pending\',
            requested_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_at DATETIME DEFAULT NULL,
            reviewed_by INT UNSIGNED DEFAULT NULL,
            UNIQUE KEY uq_student_portal_accounts_student (student_ref),
            INDEX idx_student_portal_accounts_status (status)
        ) ENGINE=InnoDB'
    );
}
function ensure_issued_rfid_uids_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS issued_rfid_uids (
            uid VARCHAR(32) NOT NULL PRIMARY KEY,
            issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            issued_by INT UNSIGNED DEFAULT NULL,
            INDEX idx_issued_rfid_uids_issued_at (issued_at)
        ) ENGINE=InnoDB'
    );
}
function ensure_audit_log_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS audit_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            admin_id INT UNSIGNED DEFAULT NULL,
            actor_username VARCHAR(60) NOT NULL,
            action VARCHAR(60) NOT NULL,
            entity_type VARCHAR(40) NOT NULL,
            entity_id VARCHAR(64) DEFAULT NULL,
            details TEXT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_audit_log_created_at (created_at),
            INDEX idx_audit_log_entity (entity_type, entity_id)
        ) ENGINE=InnoDB'
    );
}
function purge_legacy_scan_events(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS system_migrations (
            migration_key VARCHAR(100) NOT NULL PRIMARY KEY,
            applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB'
    );
    $pdo->beginTransaction();
    try {
        $migration = $pdo->prepare(
            'INSERT IGNORE INTO system_migrations (migration_key) VALUES (?)'
        );
        $migration->execute(['remove_identifying_scan_history_v1']);
        if ($migration->rowCount() === 1) {
            $table = $pdo->prepare(
                'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'scan_events\''
            );
            $table->execute();
            if ((int)$table->fetchColumn() > 0) {
                $pdo->exec('DELETE FROM scan_events');
            }
        }
        $pdo->commit();
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $error;
    }
}
function ensure_rfid_history_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS student_rfid_history (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            rfid_uid VARCHAR(32) NOT NULL,
            assigned_at DATETIME NOT NULL,
            revoked_at DATETIME DEFAULT NULL,
            assigned_by INT UNSIGNED DEFAULT NULL,
            revoked_by INT UNSIGNED DEFAULT NULL,
            INDEX idx_rfid_history_lookup (rfid_uid, assigned_at, revoked_at),
            INDEX idx_rfid_history_student (student_id, assigned_at)
        ) ENGINE=InnoDB'
    );
    $history = $pdo->query('SELECT 1 FROM student_rfid_history LIMIT 1')->fetchColumn();
    if ($history === false) {
        $pdo->exec(
            'INSERT INTO student_rfid_history (student_id, rfid_uid, assigned_at)
             SELECT id, rfid_uid, NOW() FROM students
             WHERE rfid_uid IS NOT NULL AND rfid_uid <> \'\''
        );
    }
}
function require_login(): void {
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
    $stmt = db()->prepare('SELECT username, role, is_active FROM admins WHERE id = ? LIMIT 1');
    $stmt->execute([(int)$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    if (!$admin || !(bool)$admin['is_active']) {
        $_SESSION = [];
        session_destroy();
        header('Location: login.php');
        exit;
    }
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_role'] = $admin['role'];
}
function require_role(string ...$roles): void {
    require_login();
    if (!in_array($_SESSION['admin_role'] ?? '', $roles, true)) {
        http_response_code(403);
        exit('You do not have permission to access this page.');
    }
}
function require_student_login(): array {
    $accountId = (int)($_SESSION['student_account_id'] ?? 0);
    $studentRef = (int)($_SESSION['student_ref'] ?? 0);
    $sessionUid = $_SESSION['student_rfid_uid'] ?? '';
    if ($accountId < 1 || $studentRef < 1 || !is_string($sessionUid) || $sessionUid === '') {
        header('Location: student_login.php');
        exit;
    }

    $stmt = db()->prepare(
        "SELECT a.id AS account_id, a.verified_rfid_uid, s.id AS student_ref,
                s.student_id, s.full_name, s.year_level, s.section
         FROM student_portal_accounts a
         JOIN students s ON s.id = a.student_ref
         JOIN issued_rfid_uids u ON u.uid = a.verified_rfid_uid
         WHERE a.id = ? AND s.id = ? AND a.status = 'Approved'
           AND s.card_status = 'Active'
         LIMIT 1"
    );
    $stmt->execute([$accountId, $studentRef]);
    $student = $stmt->fetch();
    if (!$student || !hash_equals((string)$student['verified_rfid_uid'], $sessionUid)) {
        unset($_SESSION['student_account_id'], $_SESSION['student_ref'], $_SESSION['student_rfid_uid']);
        header('Location: student_login.php');
        exit;
    }
    return $student;
}
function audit_event(string $action, string $entityType, string|int|null $entityId = null, array $details = []): void {
    $stmt = db()->prepare(
        'INSERT INTO audit_log (admin_id, actor_username, action, entity_type, entity_id, details)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null,
        (string)($_SESSION['admin_username'] ?? 'system'),
        $action,
        $entityType,
        $entityId === null ? null : (string)$entityId,
        $details ? json_encode($details, JSON_THROW_ON_ERROR) : null,
    ]);
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    $sessionToken = $_SESSION['csrf'] ?? '';
    $submittedToken = $_POST['csrf'] ?? '';
    if (!is_string($sessionToken) || $sessionToken === ''
        || !is_string($submittedToken) || !hash_equals($sessionToken, $submittedToken)) {
        http_response_code(403); exit('Invalid security token.');
    }
}
function require_api_key(): void {
    $provided = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if (!hash_equals(ESP32_API_KEY, $provided)) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false, 'message'=>'Unauthorized']);
        exit;
    }
}
