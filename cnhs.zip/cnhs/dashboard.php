<?php
require_once 'config.php'; require_login();
$total=(int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn();
$active=(int)db()->query("SELECT COUNT(*) FROM students WHERE card_status='Active' AND rfid_uid IS NOT NULL")->fetchColumn();
$urgentCount=(int)db()->query("SELECT COUNT(*) FROM reports WHERE priority='High' AND status NOT IN ('Resolved', 'Closed')")->fetchColumn();
$dailyReportCounts=db()->query(
    "SELECT DATE(created_at) AS report_date,
            COUNT(*) AS report_count,
            SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) AS done_count
     FROM reports
     WHERE created_at >= CURDATE() - INTERVAL 6 DAY
     GROUP BY DATE(created_at)"
)->fetchAll();
$reportCountsByDate=[];
foreach($dailyReportCounts as $row){$reportCountsByDate[$row['report_date']]=['total'=>(int)$row['report_count'],'done'=>(int)$row['done_count']];}
$chartDays=[];
$chartMax=0;
for($offset=6;$offset>=0;$offset--){
 $date=(new DateTimeImmutable('today'))->modify("-$offset days");
 $dateKey=$date->format('Y-m-d');
 $counts=$reportCountsByDate[$dateKey]??['total'=>0,'done'=>0];
 $chartDays[]=['label'=>$date->format('M j'),'count'=>$counts['total'],'done'=>$counts['done']];
 $chartMax=max($chartMax,$counts['total'],$counts['done']);
}
$chartScaleMax=max(3,(int)(ceil($chartMax/3)*3));
$chartPoints=[];
foreach($chartDays as $index=>$day){
 $x=64+($index*112);
 $y=176-(($day['count']/$chartScaleMax)*126);
 $doneY=176-(($day['done']/$chartScaleMax)*126);
 $chartPoints[]=['x'=>$x,'y'=>$y,'doneY'=>$doneY,'label'=>$day['label'],'count'=>$day['count'],'done'=>$day['done']];
}
$chartLine=implode(' ',array_map(static fn($point)=>$point['x'].','.$point['y'],$chartPoints));
$chartDoneLine=implode(' ',array_map(static fn($point)=>$point['x'].','.$point['doneY'],$chartPoints));
$chartArea='64,176 '.$chartLine.' 736,176';
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container dashboard-page"><div class="page-head dashboard-page-head"><div><span class="eyebrow">OVERVIEW</span><h1>Dashboard</h1></div><div class="stats dashboard-stats"><a class="stat stat-link" href="students.php"><span>Total students</span><strong><?=$total?></strong></a><a class="stat stat-link" href="students.php?active_cards=1"><span>Active registered cards</span><strong><?=$active?></strong></a><a class="stat stat-link urgent-stat" href="reports.php?priority=High"><span>Urgent reports</span><strong><?=$urgentCount?></strong></a></div></div>
<section class="panel">
  <div class="section-head"><h2>Recent reports</h2></div>
  <p class="chart-caption">Reports submitted and resolved or closed per day over the last 7 days</p>
  <div class="chart-legend" aria-label="Toggle chart lines">
    <button type="button" class="chart-legend-button" data-chart-series="submitted" aria-pressed="true"><i class="chart-legend-submitted" aria-hidden="true"></i>Submitted</button>
    <button type="button" class="chart-legend-button" data-chart-series="done" aria-pressed="true"><i class="chart-legend-done" aria-hidden="true"></i>Resolved / closed</button>
  </div>
  <div class="report-chart-wrap">
    <svg class="report-chart" viewBox="0 0 800 220" preserveAspectRatio="none" role="img" aria-labelledby="reportChartTitle reportChartDescription">
      <title id="reportChartTitle">Submitted and resolved or closed reports by day</title>
      <desc id="reportChartDescription">Daily submitted and resolved or closed report counts for the last seven days: <?=h(implode('; ',array_map(static fn($point)=>$point['label'].': '.$point['count'].' submitted, '.$point['done'].' resolved or closed',$chartPoints)))?>.</desc>
      <?php for($grid=0;$grid<4;$grid++): $gridY=176-($grid*42); ?>
        <line x1="64" y1="<?=$gridY?>" x2="736" y2="<?=$gridY?>" class="chart-grid"/>
        <text x="48" y="<?=$gridY+4?>" class="chart-axis" text-anchor="end"><?=($chartScaleMax*$grid/3)?></text>
      <?php endfor; ?>
      <g class="chart-series-submitted">
        <polygon points="<?=h($chartArea)?>" class="chart-area"/>
        <polyline points="<?=h($chartLine)?>" class="chart-line"/>
        <?php foreach($chartPoints as $point): ?>
          <circle cx="<?=$point['x']?>" cy="<?=$point['y']?>" r="5" class="chart-dot">
            <title><?=h($point['label'].': '.$point['count'].' submitted')?></title>
          </circle>
          <text x="<?=$point['x']?>" y="<?=$point['y']-12?>" class="chart-value" text-anchor="middle"><?=h((string)$point['count'])?></text>
        <?php endforeach; ?>
      </g>
      <g class="chart-series-done">
        <polyline points="<?=h($chartDoneLine)?>" class="chart-line chart-line-done"/>
        <?php foreach($chartPoints as $point): ?>
          <circle cx="<?=$point['x']?>" cy="<?=$point['doneY']?>" r="4" class="chart-dot chart-dot-done">
            <title><?=h($point['label'].': '.$point['done'].' done')?></title>
          </circle>
          <text x="<?=$point['x']?>" y="<?=$point['doneY']-12?>" class="chart-value chart-value-done" text-anchor="middle"><?=h((string)$point['done'])?></text>
        <?php endforeach; ?>
      </g>
      <?php foreach($chartPoints as $point): ?>
        <text x="<?=$point['x']?>" y="203" class="chart-axis" text-anchor="middle"><?=h($point['label'])?></text>
      <?php endforeach; ?>
    </svg>
  </div>
</section>
</main>
<script>
const reportChart=document.querySelector('.report-chart');
document.querySelectorAll('.chart-legend-button').forEach(button=>{
 button.addEventListener('click',()=>{
  const isVisible=button.getAttribute('aria-pressed')==='true';
  button.setAttribute('aria-pressed',String(!isVisible));
  reportChart.classList.toggle('chart-series-hidden-'+button.dataset.chartSeries,isVisible);
 });
});
</script></body></html>