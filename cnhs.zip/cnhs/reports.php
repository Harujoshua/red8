<?php
require_once 'config.php';
require_role('admin', 'counselor');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    $requestedStatus = $_POST['status'] ?? '';
    if ($id > 0 && $action === 'status' && is_string($requestedStatus)
        && in_array($requestedStatus, report_statuses(), true)) {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $status = $requestedStatus;
            $find = $pdo->prepare('SELECT reference, status FROM reports WHERE id = ? LIMIT 1 FOR UPDATE');
            $find->execute([$id]);
            $report = $find->fetch();
            if ($report) {
                $query = $pdo->prepare('UPDATE reports SET status = ? WHERE id = ?');
                $query->execute([$status, $id]);
                if ($report['status'] !== $status) {
                    audit_event('report.status_changed', 'report', $id, [
                        'reference' => $report['reference'],
                        'from' => $report['status'],
                        'to' => $status,
                    ]);
                }
                $_SESSION['flash'] = 'Report status updated to ' . $status . '.';
            } else {
                $_SESSION['flash'] = 'Report not found.';
            }
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    } elseif ($action === 'status') {
        $_SESSION['flash'] = 'Invalid report status.';
    } elseif ($id > 0 && $action === 'delete') {
        require_role('admin');
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $find = $pdo->prepare('SELECT reference FROM reports WHERE id = ? LIMIT 1 FOR UPDATE');
            $find->execute([$id]);
            $report = $find->fetch();
            if ($report) {
                audit_event('report.deleted', 'report', $id, ['reference' => $report['reference']]);
                $query = $pdo->prepare('DELETE FROM reports WHERE id = ?');
                $query->execute([$id]);
                $_SESSION['flash'] = 'Report deleted.';
            } else {
                $_SESSION['flash'] = 'Report not found.';
            }
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    header('Location: reports.php' . (($_GET['priority'] ?? '') === 'High' ? '?priority=High' : ''));
    exit;
}
$urgentOnly = ($_GET['priority'] ?? '') === 'High';
$perPage = 20;
$requestedPage = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$currentPage = is_int($requestedPage) && $requestedPage > 0 ? $requestedPage : 1;
$filterSql = $urgentOnly ? " WHERE priority = 'High' AND status NOT IN ('Resolved', 'Closed')" : '';
$countQuery = db()->query('SELECT COUNT(*) FROM reports' . $filterSql);
$totalReports = (int)$countQuery->fetchColumn();
$totalPages = max(1, (int)ceil($totalReports / $perPage));
$currentPage = min($currentPage, $totalPages);
$offset = ($currentPage - 1) * $perPage;
$reportQuery = db()->prepare(
    "SELECT r.id, r.reference, r.priority, r.status, r.category, r.incident_date, r.location
     FROM reports r
     " . ($urgentOnly ? "WHERE r.priority = 'High' AND r.status NOT IN ('Resolved', 'Closed')" : '') . "
     ORDER BY (r.priority = 'High') DESC, r.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$reportQuery->execute();
$reports = $reportQuery->fetchAll();
audit_event('reports.list_viewed', 'report', null, [
    'report_ids' => array_map(static fn(array $report): int => (int)$report['id'], $reports),
    'page' => $currentPage,
]);
$paginationBase = 'reports.php' . ($urgentOnly ? '?priority=High&page=' : '?page=');
$rangeStart = $totalReports === 0 ? 0 : $offset + 1;
$rangeEnd = min($offset + $perPage, $totalReports);
$flash = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reports</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container reports-page">
<div class="page-head"><div><span class="eyebrow">STUDENT WELLBEING</span><h1><?=$urgentOnly?'Urgent Reports':'Reports'?></h1><?php if($urgentOnly): ?><p>Reports requiring immediate attention.</p><?php endif; ?></div><?php if($urgentOnly): ?><a class="button secondary" href="reports.php">All reports</a><?php endif; ?></div>
<?php if($flash): ?><div class="toast" id="reportToast" role="status" aria-live="polite"><?=h($flash)?></div><?php endif; ?>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>Reference</th><th>Priority</th><th>Status</th><th>Concern</th><th>Incident</th><th>Location</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($reports as $report): ?>
<tr class="<?=$report['priority']==='High'?'urgent-row':''?>">
<td><code><?=h($report['reference'])?></code></td>
<td><span class="pill <?=$report['priority']==='High'?'red':'blue'?>"><?=$report['priority']==='High'?'URGENT':'Normal'?></span></td>
<td><span class="pill <?=in_array($report['status'], ['Resolved', 'Closed'], true)?'green':'blue'?>"><?=h($report['status'])?></span></td>
<td><?=h($report['category'])?></td><td><?=h($report['incident_date'])?></td>
<td><?=h($report['location'])?></td>
<td><div class="report-row-actions">
<button type="button" class="button secondary report-details-button" title="See all details" aria-label="See all details"
 data-report-id="<?=$report['id']?>">
 <i class="fa-solid fa-eye" aria-hidden="true"></i>
</button>
<form method="post" class="report-status-form" title="Update report status">
 <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
 <input type="hidden" name="action" value="status">
 <input type="hidden" name="id" value="<?=$report['id']?>">
 <label class="sr-only" for="report-status-<?=$report['id']?>">Status for report <?=h($report['reference'])?></label>
 <select id="report-status-<?=$report['id']?>" name="status">
  <?php foreach(report_statuses() as $statusOption): ?>
  <option value="<?=h($statusOption)?>" <?=$report['status']===$statusOption?'selected':''?>><?=h($statusOption)?></option>
  <?php endforeach; ?>
 </select>
 <button type="submit" class="button secondary">Update</button>
</form>
<?php if(($_SESSION['admin_role']??'')==='admin'): ?>
<form method="post" class="delete-report-form" title="Delete report">
 <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
 <input type="hidden" name="action" value="delete">
 <input type="hidden" name="id" value="<?=$report['id']?>">
 <button type="submit" class="button secondary danger" title="Delete report" aria-label="Delete report"><i class="fa-solid fa-trash" aria-hidden="true"></i></button>
</form>
<?php endif; ?>
</div>
</td></tr>
<?php endforeach; ?>
<?php if (!$reports): ?><tr><td colspan="7" class="empty">No reports submitted yet.</td></tr><?php endif; ?>
</tbody></table></div>
<nav class="pagination reports-pagination" aria-label="Reports pages">
  <span class="pagination-summary">Showing <?=$rangeStart?>–<?=$rangeEnd?> of <?=$totalReports?></span>
  <div class="pagination-links">
    <?php if($currentPage>1): ?><a href="<?=h($paginationBase.($currentPage-1))?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</a><?php else: ?><span class="disabled"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</span><?php endif; ?>
    <?php
      $firstPage=max(1,$currentPage-2);
      $lastPage=min($totalPages,$currentPage+2);
      if($firstPage>1): ?><a href="<?=h($paginationBase.'1')?>">1</a><?php if($firstPage>2): ?><span class="pagination-ellipsis">…</span><?php endif; ?><?php endif;
      for($pageNumber=$firstPage;$pageNumber<=$lastPage;$pageNumber++):
        if($pageNumber===$currentPage): ?><span class="current" aria-current="page"><?=$pageNumber?></span><?php else: ?><a href="<?=h($paginationBase.$pageNumber)?>"><?=$pageNumber?></a><?php endif;
      endfor;
      if($lastPage<$totalPages): if($lastPage<$totalPages-1): ?><span class="pagination-ellipsis">…</span><?php endif; ?><a href="<?=h($paginationBase.$totalPages)?>"><?=$totalPages?></a><?php endif;
    ?>
    <?php if($currentPage<$totalPages): ?><a href="<?=h($paginationBase.($currentPage+1))?>" aria-label="Next page">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a><?php else: ?><span class="disabled">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></span><?php endif; ?>
  </div>
</nav>
</section></main>
<dialog class="student-modal report-details-modal" id="reportDetailsModal" aria-labelledby="reportDetailsTitle">
  <div class="student-modal-head">
    <h2 id="reportDetailsTitle">Report details</h2>
    <button type="button" class="modal-close" id="closeReportDetails" aria-label="Close dialog"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
  </div>
  <dl class="report-details-grid" id="reportDetailsContent"></dl>
</dialog>
  <dialog class="student-modal delete-report-modal" id="deleteReportModal" aria-labelledby="deleteReportTitle">
    <div class="student-modal-head">
      <h2 id="deleteReportTitle">Delete report?</h2>
      <button type="button" class="modal-close" id="closeDeleteReport" aria-label="Close dialog"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
    </div>
    <p>This report will be permanently deleted.</p>
    <div class="actions">
      <button type="button" class="button secondary" id="cancelDeleteReport">Cancel</button>
      <button type="button" class="button danger" id="confirmDeleteReport">Delete</button>
    </div>
  </dialog>
  <script>
const reportDetailsModal=document.getElementById('reportDetailsModal');
const reportDetailsContent=document.getElementById('reportDetailsContent');
const reportDetailFields=[
 ['Reference','reference'],
 ['Priority','priority'],
 ['Reporting method','method'],
 ['Student','student'],
 ['Concern category','category'],
 ['Incident date','date'],
 ['Incident location','location'],
 ['Incident details','detail'],
 ['Person involved','person'],
 ['Witnesses','witnesses'],
 ['Submitted','submitted']
];
document.querySelectorAll('.report-details-button').forEach(button=>{
 button.addEventListener('click',async()=>{
  reportDetailsContent.replaceChildren();
  reportDetailsContent.textContent='Loading report details…';
  reportDetailsModal.showModal();
  try{
   const response=await fetch('api/report_details.php?id='+encodeURIComponent(button.dataset.reportId),{cache:'no-store'});
   const result=await response.json();
   if(!response.ok||!result.success) throw new Error(result.message||'Could not load report details.');
   reportDetailsContent.replaceChildren();
  reportDetailFields.forEach(([label,key])=>{
   const term=document.createElement('dt');
   const value=document.createElement('dd');
   term.textContent=label;
   value.textContent=result.report[key]||'—';
   reportDetailsContent.append(term,value);
  });
  }catch(error){
   reportDetailsContent.textContent=error.message||'Could not load report details.';
  }
 });
});
document.getElementById('closeReportDetails').addEventListener('click',()=>reportDetailsModal.close());
reportDetailsModal.addEventListener('click',event=>{
 if(event.target===reportDetailsModal) reportDetailsModal.close();
});
const reportToast=document.getElementById('reportToast');
if(reportToast){
 setTimeout(()=>{
  reportToast.classList.add('toast-hide');
  setTimeout(()=>reportToast.remove(),300);
 },2500);
}
const deleteReportModal=document.getElementById('deleteReportModal');
let pendingDeleteForm=null;
document.querySelectorAll('.delete-report-form').forEach(form=>{
 form.addEventListener('submit',event=>{
  event.preventDefault();
  pendingDeleteForm=form;
  deleteReportModal.showModal();
 });
});
document.getElementById('closeDeleteReport').addEventListener('click',()=>deleteReportModal.close());
document.getElementById('cancelDeleteReport').addEventListener('click',()=>deleteReportModal.close());
document.getElementById('confirmDeleteReport').addEventListener('click',()=>{
 if(pendingDeleteForm) pendingDeleteForm.submit();
});
deleteReportModal.addEventListener('click',event=>{
 if(event.target===deleteReportModal) deleteReportModal.close();
});
</script></body></html>
