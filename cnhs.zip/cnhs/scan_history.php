<?php
require_once 'config.php';
require_role('admin');
header('Location: students.php');
exit;
