<?php
require_once 'config.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

if (!empty($_SESSION['student_account_id'])) {
    header('Location: student_portal.php');
    exit;
}

$error = '';
$success = (string)($_SESSION['student_registration_notice'] ?? '');
unset($_SESSION['student_registration_notice']);
$studentIdInput = $_POST['student_id'] ?? '';
$studentId = is_string($studentIdInput) ? trim($studentIdInput) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $uidInput = $_POST['rfid_uid'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $uidRaw = is_string($uidInput) ? trim($uidInput) : '';
    $uid = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', $uidRaw));

    if ($studentId === '' || strlen($studentId) > 60
        || strlen($uid) < 4 || strlen($uid) > 32
        || !is_string($password) || strlen($password) < 8 || strlen($password) > 200
        || !is_string($confirmPassword) || !hash_equals($password, $confirmPassword)) {
        $error = 'Enter a valid student ID and card UID, and use matching passwords of at least 8 characters.';
    } else {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $studentQuery = $pdo->prepare(
                "SELECT id FROM students
                 WHERE student_id = ? AND card_status = 'Active'
                 LIMIT 1 FOR UPDATE"
            );
            $studentQuery->execute([$studentId]);
            $studentRef = $studentQuery->fetchColumn();

            if ($studentRef === false) {
                $pdo->rollBack();
                $error = 'We could not verify that active student ID. Check the details or contact the school office.';
            } else {
                $uidQuery = $pdo->prepare(
                    'SELECT uid FROM issued_rfid_uids WHERE uid = ? LIMIT 1 FOR UPDATE'
                );
                $uidQuery->execute([$uid]);
                if ($uidQuery->fetchColumn() === false) {
                    $pdo->rollBack();
                    $error = 'This card UID has not been issued by the school. Contact the school office.';
                } else {
                    $accountQuery = $pdo->prepare(
                        'SELECT id, status FROM student_portal_accounts WHERE student_ref = ? LIMIT 1 FOR UPDATE'
                    );
                    $accountQuery->execute([(int)$studentRef]);
                    $account = $accountQuery->fetch();
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                    if ($account && $account['status'] !== 'Rejected') {
                        $pdo->rollBack();
                        $error = 'A portal account request already exists for this student. Contact the school office if you need help.';
                    } elseif ($account) {
                        $save = $pdo->prepare(
                            "UPDATE student_portal_accounts
                             SET password_hash = ?, verified_rfid_uid = ?, status = 'Pending',
                                 requested_at = CURRENT_TIMESTAMP, reviewed_at = NULL, reviewed_by = NULL
                             WHERE id = ?"
                        );
                        $save->execute([$passwordHash, $uid, (int)$account['id']]);
                        audit_event('student.account_requested', 'student_account', (int)$account['id'], [
                            'student_ref' => (int)$studentRef,
                        ]);
                        $pdo->commit();
                        $_SESSION['student_registration_notice'] = 'Your registration request was sent. You can sign in after an administrator approves it.';
                        header('Location: student_register.php');
                        exit;
                    } else {
                        $save = $pdo->prepare(
                            "INSERT INTO student_portal_accounts
                             (student_ref, password_hash, verified_rfid_uid, status)
                             VALUES (?, ?, ?, 'Pending')"
                        );
                        $save->execute([(int)$studentRef, $passwordHash, $uid]);
                        $accountId = (int)$pdo->lastInsertId();
                        audit_event('student.account_requested', 'student_account', $accountId, [
                            'student_ref' => (int)$studentRef,
                        ]);
                        $pdo->commit();
                        $_SESSION['student_registration_notice'] = 'Your registration request was sent. You can sign in after an administrator approves it.';
                        header('Location: student_register.php');
                        exit;
                    }
                }
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Student portal registration failed: ' . $exception->getMessage());
            $error = 'Registration could not be completed. Please try again later.';
        }
    }
}
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Registration</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth">
  <main class="panel auth-panel">
    <img class="brand-logo large" src="assets/CNHS.png" alt="Carranglan National High School seal">
    <span class="eyebrow">STUDENT PORTAL</span>
    <h1>Create an account</h1>
    <p>Register with your active student ID and any UID the school has added to the shared Issued UIDs list. Unlisted UIDs cannot register. An administrator must approve your request before you can sign in.</p>
    <?php if ($error): ?><div class="error" role="alert"><?=h($error)?></div><?php endif; ?>
    <?php if ($success): ?><div class="notice" role="status"><?=h($success)?></div><?php endif; ?>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <label for="student_id">Student ID</label>
      <input id="student_id" name="student_id" required maxlength="60" value="<?=h($studentId)?>" autocomplete="username">
      <label for="rfid_uid">School-issued RFID UID</label>
      <input id="rfid_uid" name="rfid_uid" required minlength="4" maxlength="32" autocomplete="off" spellcheck="false">
      <label for="password">Create password</label>
      <input id="password" type="password" name="password" required minlength="8" maxlength="200" autocomplete="new-password">
      <label for="confirm_password">Confirm password</label>
      <input id="confirm_password" type="password" name="confirm_password" required minlength="8" maxlength="200" autocomplete="new-password">
      <button type="submit">Request account</button>
    </form>
    <p class="hint"><a href="student_login.php">Already registered? Sign in</a></p>
    <p class="hint">The UID is checked against the school's issued UID list; it does not need to be assigned to your student record. Keep your password private.</p>
  </main>
</body>
</html>
