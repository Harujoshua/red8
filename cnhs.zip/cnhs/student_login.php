<?php
require_once 'config.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

if (!empty($_SESSION['student_account_id'])) {
    header('Location: student_portal.php');
    exit;
}
if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$notice = '';
$studentIdInput = $_POST['student_id'] ?? '';
$studentId = is_string($studentIdInput) ? trim($studentIdInput) : '';
$uidInput = $_POST['rfid_uid'] ?? '';
$uidRaw = is_string($uidInput) ? trim($uidInput) : '';
$uid = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', $uidRaw));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $password = $_POST['password'] ?? '';
    if ($studentId !== '' && strlen($studentId) <= 60
        && strlen($uid) >= 4 && strlen($uid) <= 32
        && is_string($password) && strlen($password) <= 200) {
        $stmt = db()->prepare(
            'SELECT a.id AS account_id, a.password_hash, a.status AS account_status,
                    a.verified_rfid_uid, s.id AS student_ref, s.full_name, s.card_status
             FROM student_portal_accounts a
             JOIN students s ON s.id = a.student_ref
             JOIN issued_rfid_uids u ON u.uid = a.verified_rfid_uid
             WHERE s.student_id = ? LIMIT 1'
        );
        $stmt->execute([$studentId]);
        $account = $stmt->fetch();
        if ($account && password_verify($password, $account['password_hash'])
            && $account['card_status'] === 'Active'
            && hash_equals((string)$account['verified_rfid_uid'], $uid)) {
            if ($account['account_status'] === 'Pending') {
                $notice = 'Your account is waiting for administrator approval.';
            } elseif ($account['account_status'] === 'Rejected') {
                $notice = 'Your registration was not approved. Contact the school office for assistance.';
            } elseif ($account['account_status'] === 'Approved') {
                session_regenerate_id(true);
                $_SESSION['student_account_id'] = (int)$account['account_id'];
                $_SESSION['student_ref'] = (int)$account['student_ref'];
                $_SESSION['student_rfid_uid'] = $uid;
                header('Location: student_portal.php');
                exit;
            } else {
                $error = 'Sign-in failed. Check your details or contact the school office.';
            }
        } else {
            $error = 'Sign-in failed. Check your details or confirm your account has been approved.';
        }
    } else {
        $error = 'Enter your student ID, active issued card UID, and password.';
    }
}
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Portal Sign In</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth">
  <main class="panel auth-panel">
    <img class="brand-logo large" src="assets/CNHS.png" alt="Carranglan National High School seal">
    <span class="eyebrow">STUDENT PORTAL</span>
    <h1>Sign in</h1>
    <p>View the progress of concerns reported under your student record. Sign in with the same UID you used to register; it must remain on the school's issued UID list.</p>
    <?php if ($error): ?><div class="error" role="alert"><?=h($error)?></div><?php endif; ?>
    <?php if ($notice): ?><div class="notice" role="status"><?=h($notice)?></div><?php endif; ?>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <label for="student_id">Student ID</label>
      <input id="student_id" name="student_id" required maxlength="60" value="<?=h($studentId)?>" autocomplete="username">
      <label for="rfid_uid">School-issued RFID UID</label>
      <input id="rfid_uid" name="rfid_uid" required minlength="4" maxlength="32" autocomplete="off" spellcheck="false">
      <label for="password">Password</label>
      <input id="password" type="password" name="password" required maxlength="200" autocomplete="current-password">
      <button type="submit">Sign in</button>
    </form>
    <p class="hint"><a href="student_register.php">Need an account? Register with your assigned card</a></p>
    <p class="hint"><a href="report.php">Track a concern using its reference and follow-up code</a></p>
  </main>
</body>
</html>
