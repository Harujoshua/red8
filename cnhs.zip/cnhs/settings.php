<?php
require_once 'config.php';
require_login();

$adminId=(int)$_SESSION['admin_id'];
$stmt=db()->prepare('SELECT id, username, email, created_at FROM admins WHERE id=?');
$stmt->execute([$adminId]);
$admin=$stmt->fetch();
if(!$admin){
    $_SESSION=[];
    session_destroy();
    header('Location: login.php');
    exit;
}

$message='';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();

    $username=trim($_POST['username']??'');
    $email=trim($_POST['email']??'');
    $currentPassword=$_POST['current_password']??'';
    $newPassword=$_POST['new_password']??'';
    $confirmPassword=$_POST['confirm_password']??'';

    $passwordStmt=db()->prepare('SELECT password_hash FROM admins WHERE id=?');
    $passwordStmt->execute([$adminId]);
    $passwordRow=$passwordStmt->fetch();

    if($username===''){
        $error='Username is required.';
    }elseif($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)){
        $error='Enter a valid email address.';
    }elseif(!password_verify($currentPassword,$passwordRow['password_hash']??'')){
        $error='The current password is incorrect.';
    }elseif($newPassword!=='' && strlen($newPassword)<10){
        $error='The new password must be at least 10 characters.';
    }elseif($newPassword!==$confirmPassword){
        $error='The new password and confirmation do not match.';
    }else{
        try{
            if($newPassword===''){
                $update=db()->prepare('UPDATE admins SET username=?, email=? WHERE id=?');
                $update->execute([$username,$email===''?null:$email,$adminId]);
            }else{
                $update=db()->prepare('UPDATE admins SET username=?, email=?, password_hash=? WHERE id=?');
                $update->execute([$username,$email===''?null:$email,password_hash($newPassword,PASSWORD_DEFAULT),$adminId]);
            }
            $_SESSION['admin_username']=$username;
            $admin['username']=$username;
            $admin['email']=$email;
            $message='Account settings saved.';
        }catch(PDOException $e){
            if((int)$e->errorInfo[1]===1062){
                $error='That username is already in use.';
            }else{
                throw $e;
            }
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Settings</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'nav.php'; ?>
<main class="container settings-page">
  <div class="page-head settings-page-head">
    <div><span class="eyebrow">ADMIN ACCOUNT</span><h1>Settings</h1></div>
  </div>
  <?php if($message): ?><div class="notice"><?=h($message)?></div><?php endif; ?>
  <?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>
  <section class="panel settings-panel">
    <form method="post" class="settings-form">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <h2>Account details</h2>
      <label for="username">Username</label>
      <input id="username" name="username" required maxlength="60" autocomplete="username" value="<?=h($admin['username'])?>">
      <label for="email">Admin email</label>
      <input id="email" name="email" type="email" maxlength="150" autocomplete="email" value="<?=h($admin['email']??'')?>" placeholder="admin@example.com">
      <p class="hint">Report alerts also require SMTP to be configured for the server.</p>

      <h2>Password</h2>
      <div class="form-grid">
        <div>
          <label for="current_password">Current password *</label>
          <input id="current_password" name="current_password" type="password" required autocomplete="current-password">
        </div>
        <div>
          <label for="new_password">New password</label>
          <input id="new_password" name="new_password" type="password" minlength="10" autocomplete="new-password" placeholder="Leave blank to keep current">
        </div>
      </div>
      <label for="confirm_password">Confirm new password</label>
      <input id="confirm_password" name="confirm_password" type="password" minlength="10" autocomplete="new-password">

      <div class="actions">
        <button type="submit"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Save changes</button>
      </div>
    </form>
  </section>
</main>
</body>
</html>
