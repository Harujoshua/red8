<aside class="topbar">
  <a class="brand" href="student_portal.php">
    <img class="brand-logo" src="assets/CNHS.png" alt="Carranglan National High School seal">
    <span>CNHS <small>STUDENT PORTAL</small></span>
  </a>
  <button class="menu-toggle" type="button" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="studentNavigation">
    <i class="fa-solid fa-bars" aria-hidden="true"></i>
    <span class="sr-only">Toggle navigation</span>
  </button>
  <span class="sidebar-label">STUDENT MENU</span>
  <nav id="studentNavigation" aria-label="Student navigation">
    <a href="student_portal.php" aria-label="My concerns" class="<?=basename($_SERVER['PHP_SELF'])==='student_portal.php'?'active':''?>"><i class="fa-solid fa-file-lines" aria-hidden="true"></i><span>My concerns</span></a>
    <a href="report.php" aria-label="Track a concern" class="<?=basename($_SERVER['PHP_SELF'])==='report.php'?'active':''?>"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><span>Track a concern</span></a>
    <a href="student_logout.php" class="logout" aria-label="Sign out"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i><span>Sign out</span></a>
  </nav>
</aside>
<button class="mobile-nav-backdrop" type="button" aria-label="Close navigation menu" tabindex="-1"></button>
<script>
const studentMenuToggle=document.querySelector('.menu-toggle');
const studentNavigation=document.getElementById('studentNavigation');
const studentBackdrop=document.querySelector('.mobile-nav-backdrop');
const studentTopbar=document.querySelector('.topbar');
const setStudentMenuOpen=isOpen=>{
 studentMenuToggle.setAttribute('aria-expanded',String(isOpen));
 studentTopbar.classList.toggle('menu-open',isOpen);
 document.body.classList.toggle('mobile-nav-open',isOpen);
};
studentMenuToggle.addEventListener('click',()=>{
 setStudentMenuOpen(studentMenuToggle.getAttribute('aria-expanded')!=='true');
});
studentNavigation.addEventListener('click',event=>{
 if(event.target.closest('a')) setStudentMenuOpen(false);
});
studentBackdrop.addEventListener('click',()=>setStudentMenuOpen(false));
document.addEventListener('keydown',event=>{
 if(event.key==='Escape') setStudentMenuOpen(false);
});
</script>
