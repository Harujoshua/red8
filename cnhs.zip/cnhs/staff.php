<?php
require_once 'config.php';
require_role('admin');

$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $username = trim((string)($_POST['username'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $role = (string)($_POST['role'] ?? '');
        if ($username === '' || strlen($username) > 60 || strlen($password) < 10 || strlen($password) > 1024
            || !in_array($role, ['admin', 'counselor'], true)
            || ($email !== '' && (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150))) {
            $error = 'Enter a valid username, role, email, and password with at least 10 characters.';
        } else {
            $pdo = db();
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare(
                    'INSERT INTO admins (username, email, password_hash, role, is_active)
                     VALUES (?, ?, ?, ?, 1)'
                );
                $stmt->execute([
                    $username,
                    $email === '' ? null : $email,
                    password_hash($password, PASSWORD_DEFAULT),
                    $role,
                ]);
                $id = (int)$pdo->lastInsertId();
                audit_event('staff.created', 'admin', $id, ['username' => $username, 'role' => $role]);
                $pdo->commit();
                $message = 'Staff account created.';
            } catch (PDOException $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($exception->getCode() === '23000') {
                    $error = 'That username is already in use.';
                } else {
                    throw $exception;
                }
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $exception;
            }
        }
    } elseif ($action === 'update') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $role = (string)($_POST['role'] ?? '');
        $isActive = ($_POST['is_active'] ?? '') === '1' ? 1 : 0;
        if ($id === false || $id === null || $id < 1 || !in_array($role, ['admin', 'counselor'], true)) {
            $error = 'Invalid staff account selection.';
        } elseif ($id === (int)$_SESSION['admin_id'] && (!$isActive || $role !== 'admin')) {
            $error = 'You cannot deactivate or demote your own account.';
        } else {
            $pdo = db();
            $pdo->beginTransaction();
            try {
                $find = $pdo->prepare('SELECT id, username, role, is_active FROM admins WHERE id = ? LIMIT 1 FOR UPDATE');
                $find->execute([$id]);
                $old = $find->fetch();
                if (!$old) {
                    $error = 'Staff account not found.';
                } else {
                    $activeAdmins = $pdo->query(
                        "SELECT id FROM admins WHERE role = 'admin' AND is_active = 1 FOR UPDATE"
                    )->fetchAll();
                    if ($old['role'] === 'admin' && (int)$old['is_active'] === 1
                        && ($role !== 'admin' || $isActive === 0) && count($activeAdmins) <= 1) {
                        $error = 'At least one active administrator must remain.';
                    }
                }
                if ($error === '') {
                    $update = $pdo->prepare('UPDATE admins SET role = ?, is_active = ? WHERE id = ?');
                    $update->execute([$role, $isActive, $id]);
                    if ($old['role'] !== $role || (int)$old['is_active'] !== $isActive) {
                        audit_event('staff.updated', 'admin', $id, [
                            'username' => $old['username'],
                            'role_from' => $old['role'],
                            'role_to' => $role,
                            'active_from' => (int)$old['is_active'],
                            'active_to' => $isActive,
                        ]);
                    }
                    $message = 'Staff account updated.';
                }
                $pdo->commit();
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $exception;
            }
        }
    }
}

$staff = db()->query('SELECT id, username, email, role, is_active, created_at FROM admins ORDER BY username')->fetchAll();
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Staff accounts</title><link rel="stylesheet" href="assets/style.css"></head>
<body><?php include 'nav.php'; ?><main class="container">
  <div class="page-head"><div><span class="eyebrow">ACCESS CONTROL</span><h1>Staff accounts</h1><p>Administrators manage students and staff. Counselors can work with reports.</p></div></div>
  <?php if ($message): ?><div class="notice" role="status"><?=h($message)?></div><?php endif; ?>
  <?php if ($error): ?><div class="error" role="alert"><?=h($error)?></div><?php endif; ?>
  <section class="panel">
    <h2>Create staff account</h2>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <input type="hidden" name="action" value="create">
      <div><label for="username">Username</label><input id="username" name="username" required maxlength="60" autocomplete="off"></div>
      <div><label for="email">Email (optional)</label><input id="email" name="email" type="email" maxlength="150"></div>
      <div><label for="password">Temporary password</label><input id="password" name="password" type="password" required minlength="10" autocomplete="new-password"></div>
      <div><label for="role">Role</label><select id="role" name="role"><option value="counselor">Counselor</option><option value="admin">Administrator</option></select></div>
      <div class="actions"><button type="submit">Create account</button></div>
    </form>
  </section>
  <section class="panel"><h2>Manage staff</h2><div class="table-wrap"><table>
    <thead><tr><th>Username</th><th>Email</th><th>Role</th><th>State</th><th>Created</th><th>Save</th></tr></thead><tbody>
    <?php foreach ($staff as $account): $formId = 'staff-' . (int)$account['id']; ?><tr>
      <td><?=h($account['username'])?><?= (int)$account['id'] === (int)$_SESSION['admin_id'] ? ' (you)' : '' ?></td>
      <td><?=h($account['email'] ?? '—')?></td>
      <td><select form="<?=h($formId)?>" name="role" aria-label="Role for <?=h($account['username'])?>">
        <option value="admin" <?=$account['role']==='admin'?'selected':''?>>Administrator</option>
        <option value="counselor" <?=$account['role']==='counselor'?'selected':''?>>Counselor</option>
      </select></td>
      <td><select form="<?=h($formId)?>" name="is_active" aria-label="Account state for <?=h($account['username'])?>">
        <option value="1" <?=(int)$account['is_active']===1?'selected':''?>>Active</option>
        <option value="0" <?=(int)$account['is_active']===0?'selected':''?>>Inactive</option>
      </select></td>
      <td><?=h($account['created_at'])?></td>
      <td><form id="<?=h($formId)?>" method="post">
        <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?=(int)$account['id']?>">
        <button type="submit" class="button secondary">Save</button>
      </form></td>
    </tr><?php endforeach; ?>
    </tbody>
  </table></div></section>
</main></body></html>
