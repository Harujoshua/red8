<?php
require_once 'config.php';
require_role('admin');

$flash = (string)($_SESSION['issued_uids_flash'] ?? '');
unset($_SESSION['issued_uids_flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $uidInput = $_POST['rfid_uid'] ?? '';
    $uidRaw = is_string($uidInput) ? trim($uidInput) : '';
    $uid = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', $uidRaw));

    if (strlen($uid) < 4 || strlen($uid) > 32) {
        $flash = 'Enter a valid card UID.';
    } else {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $save = $pdo->prepare(
                'INSERT INTO issued_rfid_uids (uid, issued_by) VALUES (?, ?)'
            );
            $save->execute([$uid, (int)$_SESSION['admin_id']]);
            audit_event('rfid.uid_issued', 'issued_rfid_uid', $uid);
            $pdo->commit();
            $_SESSION['issued_uids_flash'] = 'UID ' . $uid . ' was added to the shared issued list. Students can now use it for registration and sign-in.';
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($exception->getCode() === '23000') {
                $_SESSION['issued_uids_flash'] = 'That UID is already on the issued list.';
            } else {
                error_log('RFID UID issuance failed: ' . $exception->getMessage());
                $_SESSION['issued_uids_flash'] = 'The UID could not be added. Please try again.';
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('RFID UID issuance failed: ' . $exception->getMessage());
            $_SESSION['issued_uids_flash'] = 'The UID could not be added. Please try again.';
        }
        header('Location: issued_uids.php');
        exit;
    }

    $_SESSION['issued_uids_flash'] = $flash;
    header('Location: issued_uids.php');
    exit;
}

$searchInput = $_GET['q'] ?? '';
$search = is_string($searchInput) ? trim($searchInput) : '';
$perPage = 25;
$requestedPage = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$currentPage = is_int($requestedPage) && $requestedPage > 0 ? $requestedPage : 1;
$where = '';
$params = [];
if ($search !== '') {
    $where = ' WHERE u.uid LIKE ?';
    $params[] = '%' . $search . '%';
}
$count = db()->prepare('SELECT COUNT(*) FROM issued_rfid_uids u' . $where);
$count->execute($params);
$total = (int)$count->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$currentPage = min($currentPage, $totalPages);
$offset = ($currentPage - 1) * $perPage;
$query = db()->prepare(
    'SELECT u.uid, u.issued_at, a.username AS issued_by_username
     FROM issued_rfid_uids u
     LEFT JOIN admins a ON a.id = u.issued_by' . $where . '
     ORDER BY u.issued_at DESC, u.uid
     LIMIT ' . $perPage . ' OFFSET ' . $offset
);
$query->execute($params);
$uids = $query->fetchAll();
$paginationUrl = static fn(int $page): string => 'issued_uids.php?' . http_build_query(
    array_filter(['q' => $search, 'page' => $page], static fn($value): bool => $value !== '')
);
$rangeStart = $total === 0 ? 0 : $offset + 1;
$rangeEnd = min($offset + $perPage, $total);
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Issued UIDs</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'nav.php'; ?>
<main class="container issued-uids-page">
  <div class="page-head">
    <div><span class="eyebrow">CARD MANAGEMENT</span><h1>Issued UIDs</h1><p>Shared allowlist of cards students may use for portal registration and sign-in.</p></div>
    <div class="actions"><div class="stat"><span>Issued UIDs</span><strong><?=$total?></strong></div><button type="button" class="button" id="issueUidButton"><i class="fa-solid fa-id-card" aria-hidden="true"></i> Add UID</button></div>
  </div>
  <?php if ($flash): ?><div class="notice" role="status"><?=h($flash)?></div><?php endif; ?>
  <section class="panel">
    <div class="section-head">
      <h2>Allowed card UIDs</h2>
      <form class="search" method="get">
        <label class="sr-only" for="uidSearch">Search UID</label>
        <input id="uidSearch" name="q" placeholder="Search UID" value="<?=h($search)?>">
        <button class="button secondary" type="submit" aria-label="Search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></button>
      </form>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>UID</th><th>Added by</th><th>Added on</th></tr></thead>
        <tbody>
        <?php foreach ($uids as $issuedUid): ?>
          <tr>
            <td><code><?=h($issuedUid['uid'])?></code></td>
            <td><?=h($issuedUid['issued_by_username'] ?: 'System')?></td>
            <td><?=h($issuedUid['issued_at'])?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$uids): ?><tr><td colspan="3" class="empty"><?=$search!==''?'No matching issued UIDs.':'No UIDs have been added to the shared list.'?></td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
    <nav class="pagination" aria-label="Issued UID pages">
      <span class="pagination-summary">Showing <?=$rangeStart?>–<?=$rangeEnd?> of <?=$total?></span>
      <div class="pagination-links">
        <?php if ($currentPage > 1): ?><a href="<?=h($paginationUrl($currentPage-1))?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</a><?php else: ?><span class="disabled">Previous</span><?php endif; ?>
        <span class="current" aria-current="page"><?=$currentPage?> / <?=$totalPages?></span>
        <?php if ($currentPage < $totalPages): ?><a href="<?=h($paginationUrl($currentPage+1))?>" aria-label="Next page">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a><?php else: ?><span class="disabled">Next</span><?php endif; ?>
      </div>
    </nav>
  </section>
</main>
<dialog class="student-modal" id="issueUidModal" aria-labelledby="issueUidTitle">
  <div class="student-modal-head">
    <h2 id="issueUidTitle">Add an issued UID</h2>
    <button type="button" class="modal-close" id="closeIssueUidModal" aria-label="Close dialog"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
  </div>
  <p>Add a card UID to the shared allowlist. It is not assigned to a specific student; students must enter a listed UID during registration and use their registered UID when signing in.</p>
  <form method="post" id="issueUidForm">
    <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
    <label for="issueUid">Card UID</label>
    <div class="inline">
      <input id="issueUid" name="rfid_uid" required minlength="4" maxlength="32" placeholder="Scan or enter UID" autocomplete="off" spellcheck="false">
      <button type="button" class="button secondary" id="scanIssueUid"><i class="fa-solid fa-id-card" aria-hidden="true"></i> Scan card</button>
    </div>
    <p class="hint" id="issueUidStatus">Scanning waits up to 30 seconds. Adding the UID makes it available to student registrations.</p>
    <div class="actions">
      <button type="submit">Add to issued list</button>
      <button type="button" class="button secondary" id="cancelIssueUid">Cancel</button>
    </div>
  </form>
</dialog>
<script>
const issueUidModal=document.getElementById('issueUidModal');
let issueScanTimer=null,issueLastScanId=0,issueCaptureDeadline=0;
document.getElementById('issueUidButton').addEventListener('click',()=>issueUidModal.showModal());
document.getElementById('closeIssueUidModal').addEventListener('click',()=>issueUidModal.close());
document.getElementById('cancelIssueUid').addEventListener('click',()=>issueUidModal.close());
issueUidModal.addEventListener('click',event=>{
 if(event.target===issueUidModal) issueUidModal.close();
});
issueUidModal.addEventListener('close',()=>{
 clearTimeout(issueScanTimer);
 issueScanTimer=null;
 issueCaptureDeadline=0;
 document.getElementById('scanIssueUid').disabled=false;
});
document.getElementById('scanIssueUid').addEventListener('click',()=>{
 const status=document.getElementById('issueUidStatus');
 const button=document.getElementById('scanIssueUid');
 status.textContent='Waiting for a card... tap it on the PN532 reader.';
 button.disabled=true;
 const form=new URLSearchParams({csrf:<?=json_encode(csrf_token())?>});
 fetch('api/arm_scan.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form.toString(),cache:'no-store'})
  .then(async response=>{const data=await response.json();if(!response.ok||!data.success)throw new Error(data.message||'Could not start card capture.');return data;})
  .then(data=>{issueLastScanId=data.scan_id||0;issueCaptureDeadline=Date.now()+30000;pollIssueUidScan();})
  .catch(error=>{status.textContent=error.message||'Could not contact server.';button.disabled=false;});
});
function pollIssueUidScan(){
 if(!issueUidModal.open) return;
 const status=document.getElementById('issueUidStatus');
 const button=document.getElementById('scanIssueUid');
 if(Date.now()>=issueCaptureDeadline){
  status.textContent='Card capture expired. Click “Scan card” to try again.';
  button.disabled=false;
  return;
 }
 fetch('api/latest_scan.php?after='+issueLastScanId,{cache:'no-store'})
  .then(response=>response.json())
  .then(data=>{
   if(data.success&&data.scan_id>issueLastScanId){
    document.getElementById('issueUid').value=data.uid;
    status.textContent='Card detected: '+data.uid;
    button.disabled=false;
    return;
   }
   issueScanTimer=setTimeout(pollIssueUidScan,1000);
  })
  .catch(()=>{status.textContent='Connection error. Check the website and card reader.';button.disabled=false;});
}
</script>
</body>
</html>
