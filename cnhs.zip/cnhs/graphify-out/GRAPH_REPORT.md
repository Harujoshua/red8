# Graph Report - cnhs  (2026-11-20)

## Corpus Check
- 45 files · ~146,331 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 2 file(s) not represented in the graph (top: .css 1, .ino 1)

## Summary
- 87 nodes · 77 edges · 26 communities (7 shown, 19 thin omitted)
- Extraction: 79% EXTRACTED · 21% INFERRED · 0% AMBIGUOUS · INFERRED: 16 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Concern Categories and Icons
- CNHS Branding and Login
- Runtime Configuration
- Report Submission API
- Reports Management UI
- Scan Cache Utilities
- Dashboard Charts
- PHP Dependencies
- Student Management

## God Nodes (most connected - your core abstractions)
1. `Student Concern Reporting Categories` - 15 edges
2. `db()` - 7 edges
3. `Carranglan National High School crest` - 6 edges
4. `submit_report()` - 5 edges
5. `write_latest_scan_cache()` - 4 edges
6. `report_allowed_values()` - 3 edges
7. `scan_cache_path()` - 3 edges
8. `read_latest_scan_cache()` - 3 edges
9. `require` - 3 edges
10. `ensure_admin_login_attempts_table()` - 3 edges

## Surprising Connections (you probably didn't know these)
- `report_allowed_values()` --defines--> `Student Concern Reporting Categories`  [EXTRACTED]
  api/report_common.php → assets/CNHS-BANNER.png
- `submit_report()` --calls--> `db()`  [INFERRED]
  api/report_common.php → config.php
- `submit_report()` --calls--> `send_admin_report_email()`  [INFERRED]
  api/report_common.php → mailer.php
- `send_admin_report_email()` --calls--> `db()`  [INFERRED]
  mailer.php → config.php
- `Academic Problems concern icon` --represents_concern_category--> `Student Concern Reporting Categories`  [INFERRED]
  assets/ACADEMIC-PROBLEMS.png → assets/CNHS-BANNER.png

## Import Cycles
- None detected.

## Communities (26 total, 19 thin omitted)

### Community 0 - "Concern Categories and Icons"
Cohesion: 0.14
Nodes (14): Student Concern Reporting Categories, Academic Problems concern icon, Anxiety and Stress concern icon, Attendance Issues concern icon, Bullying concern icon, Cyberbullying concern icon, Discrimination concern icon, Family Problems concern icon (+6 more)

### Community 1 - "CNHS Branding and Login"
Cohesion: 0.18
Nodes (7): Student Counseling Support Poster, Carranglan National High School crest, Carranglan, Nueva Ecija, countdown, countdownUnit, secondsLeft, 1966

### Community 2 - "Runtime Configuration"
Cohesion: 0.29
Nodes (4): db(), ensure_admin_email_column(), ensure_admin_login_attempts_table(), ensure_reports_status_column()

### Community 3 - "Report Submission API"
Cohesion: 0.47
Nodes (4): report_allowed_values(), report_error(), submit_report(), send_admin_report_email()

### Community 4 - "Reports Management UI"
Cohesion: 0.33
Nodes (5): deleteReportModal, reportDetailFields, reportDetailsContent, reportDetailsModal, reportToast

### Community 5 - "Scan Cache Utilities"
Cohesion: 0.80
Nodes (4): read_latest_scan_cache(), scan_cache_lock_path(), scan_cache_path(), write_latest_scan_cache()

### Community 8 - "PHP Dependencies"
Cohesion: 0.50
Nodes (3): require, php, phpmailer/phpmailer

## Knowledge Gaps
- **15 isolated node(s):** `1966`, `Carranglan, Nueva Ecija`, `Academic Problems concern icon`, `Anxiety and Stress concern icon`, `Attendance Issues concern icon` (+10 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 62 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **19 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Student Concern Reporting Categories` connect `Concern Categories and Icons` to `CNHS Branding and Login`, `Report Submission API`?**
  _High betweenness centrality (0.172) - this node is a cross-community bridge._
- **Are the 13 inferred relationships involving `Student Concern Reporting Categories` (e.g. with `Academic Problems concern icon` and `Anxiety and Stress concern icon`) actually correct?**
  _`Student Concern Reporting Categories` has 13 INFERRED edges - model-reasoned connections that need verification._
- **What connects `1966`, `Carranglan, Nueva Ecija`, `Academic Problems concern icon` to the rest of the system?**
  _15 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Concern Categories and Icons` be split into smaller, more focused modules?**
  _Cohesion score 0.14285714285714285 - nodes in this community are weakly interconnected._
- **Why does `report_allowed_values()` connect `Report Submission API` to `Concern Categories and Icons`?**
  _High betweenness centrality (0.109) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `db()` (e.g. with `submit_report()` and `send_admin_report_email()`) actually correct?**
  _`db()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **Why does `submit_report()` connect `Report Submission API` to `Runtime Configuration`?**
  _High betweenness centrality (0.103) - this node is a cross-community bridge._