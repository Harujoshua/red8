# Graph Report - cnhs  (2026-11-18)

## Corpus Check
- Corpus is ~36,605 words - fits in a single context window. You may not need a graph.

## Summary
- 88 nodes · 75 edges · 29 communities (8 shown, 21 thin omitted)
- Extraction: 65% EXTRACTED · 35% INFERRED · 0% AMBIGUOUS · INFERRED: 26 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Reporting System
- Runtime Configuration
- Reporting API
- Database Schema
- Report Interface
- Dashboard Charts
- Login Countdown
- PHP Dependencies
- Student Card UI
- CNHS Identity

## God Nodes (most connected - your core abstractions)
1. `db()` - 7 edges
2. `submit_report()` - 5 edges
3. `Report row` - 5 edges
4. `ESP32-S3` - 5 edges
5. `cnhs_rfid` - 4 edges
6. `Student concern reporting workflow` - 4 edges
7. `require` - 3 edges
8. `ensure_admin_login_attempts_table()` - 3 edges
9. `ensure_admin_email_column()` - 3 edges
10. `ensure_reports_status_column()` - 3 edges

## Surprising Connections (you probably didn't know these)
- `submit_report()` --calls--> `db()`  [INFERRED]
  api/report_common.php → config.php
- `submit_report()` --calls--> `send_admin_report_email()`  [INFERRED]
  api/report_common.php → mailer.php
- `send_admin_report_email()` --calls--> `db()`  [INFERRED]
  mailer.php → config.php

## Import Cycles
- None detected.

## Communities (29 total, 21 thin omitted)

### Community 0 - "Reporting System"
Cohesion: 0.15
Nodes (17): Administrator email notifications, Anonymous reporting, cnhs_rfid, ESP32-S3, Immediate-assistance report, PHP + MySQL admin website, PN532, CNHS RFID Student Reporting Website (+9 more)

### Community 1 - "Runtime Configuration"
Cohesion: 0.29
Nodes (4): db(), ensure_admin_email_column(), ensure_admin_login_attempts_table(), ensure_reports_status_column()

### Community 2 - "Reporting API"
Cohesion: 0.47
Nodes (4): report_allowed_values(), report_error(), submit_report(), send_admin_report_email()

### Community 3 - "Database Schema"
Cohesion: 0.40
Nodes (5): admin_login_attempts, admins, reports, scan_events, students

### Community 4 - "Report Interface"
Cohesion: 0.33
Nodes (5): deleteReportModal, reportDetailFields, reportDetailsContent, reportDetailsModal, reportToast

### Community 6 - "Login Countdown"
Cohesion: 0.40
Nodes (3): countdown, countdownUnit, secondsLeft

### Community 7 - "PHP Dependencies"
Cohesion: 0.50
Nodes (3): require, php, phpmailer/phpmailer

### Community 9 - "CNHS Identity"
Cohesion: 0.67
Nodes (3): Carranglan National High School crest, Carranglan, Nueva Ecija, 1966

## Knowledge Gaps
- **8 isolated node(s):** `CNHS RFID Student Reporting Website`, `XPT2046 touchscreen`, `ST7789 TFT display`, `Submission token`, `Immediate-assistance report` (+3 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 57 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **21 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `db()` connect `Runtime Configuration` to `Reporting API`?**
  _High betweenness centrality (0.017) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `db()` (e.g. with `submit_report()` and `send_admin_report_email()`) actually correct?**
  _`db()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `CNHS RFID Student Reporting Website`, `XPT2046 touchscreen`, `ST7789 TFT display` to the rest of the system?**
  _8 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Are the 2 inferred relationships involving `submit_report()` (e.g. with `db()` and `send_admin_report_email()`) actually correct?**
  _`submit_report()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **Are the 5 inferred relationships involving `Report row` (e.g. with `Administrator email notifications` and `Anonymous reporting`) actually correct?**
  _`Report row` has 5 INFERRED edges - model-reasoned connections that need verification._
- **Are the 5 inferred relationships involving `ESP32-S3` (e.g. with `PN532` and `API scan endpoint`) actually correct?**
  _`ESP32-S3` has 5 INFERRED edges - model-reasoned connections that need verification._