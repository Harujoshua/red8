<?php
require_once 'config.php';
$message = '';
$count = (int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0) {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || strlen($password) < 10) {
        $message = 'Enter a username and a password with at least 10 characters.';
    } else {
        $stmt = db()->prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
        $message = 'Admin created. Delete setup_admin.php now, then sign in.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Initial Admin Setup</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth"><form class="panel auth-panel" method="post"><img class="brand-logo large" src="assets/CNHS.png" alt="Carranglan National High School seal"><h1>Initial admin setup</h1><p>Create the first administrator account.</p><?php if($message): ?><div class="notice"><?=h($message)?></div><?php endif; ?><?php if($count===0): ?><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Username</label><input name="username" required maxlength="60"><label>Password (minimum 10 characters)</label><input type="password" name="password" required minlength="10"><button>Create administrator</button><?php else: ?><p>An administrator already exists. Delete this file and use the login page.</p><?php endif; ?></form></body></html>
