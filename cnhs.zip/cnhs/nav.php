<aside class="topbar">
  <a class="brand" href="dashboard.php">
    <img class="brand-logo" src="assets/CNHS.png" alt="Carranglan National High School seal">
    <span>CNHS <small>STUDENT REPORTING SYSTEM</small></span>
  </a>
  <button class="menu-toggle" type="button" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="mainNavigation">
    <i class="fa-solid fa-bars" aria-hidden="true"></i>
    <span class="sr-only">Toggle navigation</span>
  </button>
  <span class="sidebar-label">MAIN MENU</span>
  <nav id="mainNavigation" aria-label="Main navigation">
    <a href="dashboard.php" aria-label="Dashboard" class="<?=basename($_SERVER['PHP_SELF'])==='dashboard.php'?'active':''?>"><i class="fa-solid fa-gauge-high" aria-hidden="true"></i><span>Dashboard</span></a>
    <?php if(($_SESSION['admin_role']??'')==='admin'): ?>
    <a href="students.php" aria-label="Students" class="<?=basename($_SERVER['PHP_SELF'])==='students.php'?'active':''?>"><i class="fa-solid fa-user-graduate" aria-hidden="true"></i><span>Students</span></a>
    <a href="student_accounts.php" aria-label="Student account approvals" class="<?=basename($_SERVER['PHP_SELF'])==='student_accounts.php'?'active':''?>"><i class="fa-solid fa-user-check" aria-hidden="true"></i><span>Account approvals</span></a>
    <a href="issued_uids.php" aria-label="Issued UIDs" class="<?=basename($_SERVER['PHP_SELF'])==='issued_uids.php'?'active':''?>"><i class="fa-solid fa-id-card" aria-hidden="true"></i><span>Issued UIDs</span></a>
    <a href="activity.php" aria-label="Recent Activity" class="<?=basename($_SERVER['PHP_SELF'])==='activity.php'?'active':''?>"><i class="fa-solid fa-clock" aria-hidden="true"></i><span>Recent Activity</span></a>
    <a href="staff.php" aria-label="Staff accounts" class="<?=basename($_SERVER['PHP_SELF'])==='staff.php'?'active':''?>"><i class="fa-solid fa-user-shield" aria-hidden="true"></i><span>Staff</span></a>
    <a href="audit.php" aria-label="Audit log" class="<?=basename($_SERVER['PHP_SELF'])==='audit.php'?'active':''?>"><i class="fa-solid fa-list-check" aria-hidden="true"></i><span>Audit log</span></a>
    <?php endif; ?>
    <a href="reports.php" aria-label="Reports" class="<?=basename($_SERVER['PHP_SELF'])==='reports.php'?'active':''?>"><i class="fa-solid fa-file-lines" aria-hidden="true"></i><span>Reports</span></a>
    <a href="settings.php" aria-label="Settings" class="<?=basename($_SERVER['PHP_SELF'])==='settings.php'?'active':''?>"><i class="fa-solid fa-gear" aria-hidden="true"></i><span>Settings</span></a>
    <a href="logout.php" class="logout" aria-label="Sign out" id="signOutLink"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i><span>Sign out</span></a>
  </nav>
</aside>
<button class="mobile-nav-backdrop" type="button" aria-label="Close navigation menu" tabindex="-1"></button>
<dialog class="student-modal delete-report-modal sign-out-modal" id="signOutModal" aria-labelledby="signOutTitle" aria-describedby="signOutDescription">
  <div class="student-modal-head">
    <h2 id="signOutTitle">Sign out?</h2>
    <button type="button" class="modal-close" id="closeSignOutModal" aria-label="Cancel sign out"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
  </div>
  <p id="signOutDescription">Are you sure you want to sign out of your account?</p>
  <div class="actions">
    <button type="button" class="button secondary" id="cancelSignOut">Cancel</button>
    <a class="button" href="logout.php">Sign out</a>
  </div>
</dialog>
<script>
const menuToggle=document.querySelector('.menu-toggle');
const mainNavigation=document.getElementById('mainNavigation');
const mobileNavBackdrop=document.querySelector('.mobile-nav-backdrop');
const topbar=document.querySelector('.topbar');
const signOutLink=document.getElementById('signOutLink');
const signOutModal=document.getElementById('signOutModal');
const setMenuOpen=isOpen=>{
 menuToggle.setAttribute('aria-expanded',String(isOpen));
 topbar.classList.toggle('menu-open',isOpen);
 document.body.classList.toggle('mobile-nav-open',isOpen);
};
menuToggle.addEventListener('click',()=>{
 const isOpen=menuToggle.getAttribute('aria-expanded')==='true';
 setMenuOpen(!isOpen);
});
mainNavigation.addEventListener('click',event=>{
 const link=event.target.closest('a');
 if(!link) return;
 if(link===signOutLink){
  event.preventDefault();
  setMenuOpen(false);
  signOutModal.showModal();
 }else{
  setMenuOpen(false);
 }
});
document.getElementById('closeSignOutModal').addEventListener('click',()=>signOutModal.close());
document.getElementById('cancelSignOut').addEventListener('click',()=>signOutModal.close());
signOutModal.addEventListener('click',event=>{
 if(event.target===signOutModal) signOutModal.close();
});
mobileNavBackdrop.addEventListener('click',()=>setMenuOpen(false));
document.addEventListener('keydown',event=>{
 if(event.key==='Escape') setMenuOpen(false);
});
</script>