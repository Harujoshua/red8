<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/scan_cache.php';
require_api_key();
header('Content-Type: application/json');
$input=json_decode(file_get_contents('php://input'),true);
$uid=strtoupper(preg_replace('/[^A-Fa-f0-9]/','',(string)($input['uid']??'')));
$device=substr(trim((string)($input['device_id']??'ESP32-S3')),0,80);
if(strlen($uid)<4 || strlen($uid)>32){http_response_code(400);echo json_encode(['success'=>false,'message'=>'Invalid UID']);exit;}
try {
    $scan=write_latest_scan_cache($uid,$device);
    $studentStmt=db()->prepare('SELECT id,card_status FROM students WHERE rfid_uid=? LIMIT 1');
    $studentStmt->execute([$uid]);
    $student=$studentStmt->fetch();
} catch (Throwable $error) {
    error_log('Scan processing failed: '.$error->getMessage());
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Could not process scan']);
    exit;
}
echo json_encode([
    'success'=>true,
    'message'=>'Scan received',
    'uid'=>$uid,
    'scan_id'=>(int)($scan['scan_id']??0),
    'registered'=>(bool)$student,
    'student_ref'=>$student ? (int)$student['id'] : null,
    'card_status'=>$student['card_status']??null
]);
