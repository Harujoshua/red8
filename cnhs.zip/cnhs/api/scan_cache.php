<?php

function scan_cache_path(): string {
    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR . 'cnhs_rfid_latest_scan.json';
}

function scan_cache_lock_path(): string {
    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR . 'cnhs_rfid_latest_scan.lock';
}

function read_latest_scan_cache(): array {
    $path = scan_cache_path();
    if (!is_file($path)) {
        return [];
    }

    $contents = @file_get_contents($path);
    if (!is_string($contents) || $contents === '') {
        return [];
    }

    $data = json_decode($contents, true);
    return is_array($data) ? $data : [];
}

function write_scan_cache(array $data): void {
    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    if (!is_string($json) || @file_put_contents(scan_cache_path(), $json, LOCK_EX) === false) {
        throw new RuntimeException('Could not update scan cache.');
    }
}

function with_scan_cache_lock(callable $callback): mixed {
    $lock = fopen(scan_cache_lock_path(), 'c');
    if ($lock === false) {
        throw new RuntimeException('Could not open scan cache lock.');
    }

    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock scan cache.');
        }

        return $callback(read_latest_scan_cache());
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function arm_latest_scan_capture(): int {
    return with_scan_cache_lock(static function (array $latest): int {
        $scanId = (int)($latest['scan_id'] ?? 0);
        write_scan_cache([
            'scan_id' => $scanId,
            'uid' => null,
            'device_id' => null,
            'scanned_at' => 0,
            'armed_until' => time() + 30,
        ]);
        return $scanId;
    });
}

function write_latest_scan_cache(string $uid, string $device): ?array {
    return with_scan_cache_lock(static function (array $latest) use ($uid, $device): ?array {
        if ((int)($latest['armed_until'] ?? 0) < time()) {
            return null;
        }
        $data = [
            'scan_id' => ((int)($latest['scan_id'] ?? 0)) + 1,
            'uid' => $uid,
            'device_id' => $device,
            'scanned_at' => time(),
            'armed_until' => 0,
        ];
        write_scan_cache($data);
        return $data;
    });
}
