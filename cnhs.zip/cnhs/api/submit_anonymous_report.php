<?php
require_once __DIR__ . '/report_common.php';
submit_report(false);
