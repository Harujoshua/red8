<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/scan_cache.php';
require_role('admin');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$after=filter_var($_GET['after']??null,FILTER_VALIDATE_INT);
$after=is_int($after)&&$after>=0?$after:-1;
$row=read_latest_scan_cache();
$scanId=(int)($row['scan_id']??0);
if ($after < 0 || $scanId <= $after
    || (int)($row['scanned_at']??0) < time()-30
    || empty($row['uid'])) {
    $row=[];
}
echo json_encode([
    'success'=>true,
    'scan_id'=>(int)($row['scan_id']??$scanId),
    'uid'=>$row['uid']??null,
    'device_id'=>$row['device_id']??null,
    'scanned_at'=>$row['scanned_at']??null,
]);
