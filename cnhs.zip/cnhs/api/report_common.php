<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../mailer.php';
require_api_key();
header('Content-Type: application/json; charset=utf-8');

function report_error(int $status, string $message): void {
    http_response_code($status);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

function report_allowed_values(): array {
    return [
        'categories' => [
            'Bullying', 'Theft', 'Harassment', 'Fighting / Physical Violence',
            'Verbal Abuse', 'Cyberbullying', 'Discrimination',
            'Academic Problems', 'Attendance Issues', 'Family Problems',
            'Relationship Problems', 'Anxiety and Stress', 'Vandalism',
            'Other Concerns',
        ],
        'dates' => ['Today', 'Yesterday', 'This Week', 'Other / Not Sure'],
        'locations' => [
            'Classroom', 'Hallway', 'Canteen', 'Library', 'School Grounds',
            'Comfort Room', 'Office', 'Outside Campus', 'Other / Not Sure',
        ],
        'details' => [
            'Bullying' => [
                'Verbal Bullying', 'Physical Bullying', 'Social Exclusion',
                'Repeated Teasing', 'Online Bullying', 'Other',
            ],
            'Theft' => [
                'Stolen Personal Belongings', 'Missing Money',
                'Stolen School Supplies', 'Stolen Electronic Device', 'Other',
            ],
            'Harassment' => [
                'Verbal Harassment', 'Sexual Harassment', 'Unwanted Attention',
                'Threatening Behavior', 'Other',
            ],
            'Fighting / Physical Violence' => [
                'Physical Fight', 'Pushing', 'Hitting', 'Threats of Violence', 'Other',
            ],
            'Verbal Abuse' => [
                'Insults or Name-calling', 'Threats', 'Repeated Shouting',
                'Humiliation', 'Other',
            ],
            'Cyberbullying' => [
                'Online Insults', 'Threatening Messages',
                'Sharing Private Information', 'Fake Accounts', 'Other',
            ],
            'Discrimination' => [
                'Disability', 'Religion', 'Gender', 'Ethnicity or Background', 'Other',
            ],
            'Academic Problems' => [
                'Difficulty with Coursework', 'Academic Pressure',
                'Unfair Treatment', 'Conflict About Grades', 'Other',
            ],
            'Attendance Issues' => [
                'Frequent Absences', 'Tardiness', 'Unable to Attend',
                'Attendance Record Concern', 'Other',
            ],
            'Family Problems' => [
                'Conflict at Home', 'Family Separation', 'Caregiving Stress',
                'Housing or Financial Stress', 'Other',
            ],
            'Relationship Problems' => [
                'Peer Conflict', 'Friendship Problem', 'Breakup',
                'Unwanted Contact', 'Other',
            ],
            'Anxiety and Stress' => [
                'School-related Stress', 'Anxiety', 'Feeling Overwhelmed',
                'Panic or Fear', 'Other',
            ],
            'Vandalism' => [
                'Damaged School Property', 'Graffiti', 'Damaged Personal Property',
                'Other',
            ],
            'Other Concerns' => [
                'Safety Concern', 'Wellbeing Concern', 'School Environment',
                'Other',
            ],
        ],
        'people' => [
            'Student', 'Teacher', 'Staff', 'Unknown', 'Prefer not to say',
        ],
        'witnesses' => ['Yes', 'No', 'Not Sure'],
    ];
}

function submit_report(bool $identified): void {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        report_error(400, 'Invalid JSON body.');
    }

    $allowedKeys = [
        'category', 'incident_date', 'location', 'incident_detail',
        'person_involved', 'witnesses', 'immediate_assistance', 'submission_token',
        'tracking_token',
    ];
    if ($identified) {
        $allowedKeys[] = 'student_ref';
    }
    if (array_diff(array_keys($input), $allowedKeys)) {
        report_error(
            400,
            $identified
                ? 'Submission contains unsupported fields.'
                : 'Anonymous submissions must not include student or card identifiers.'
        );
    }

    $allowed = report_allowed_values();
    $category = $input['category'] ?? null;
    $incidentDate = $input['incident_date'] ?? null;
    $location = $input['location'] ?? null;
    $detail = $input['incident_detail'] ?? null;
    $person = $input['person_involved'] ?? null;
    $witnesses = $input['witnesses'] ?? null;
    $urgent = $input['immediate_assistance'] ?? null;
    $submissionToken = $input['submission_token'] ?? null;
    $trackingToken = $input['tracking_token'] ?? null;

    if (!is_string($category) || !in_array($category, $allowed['categories'], true)
        || !is_string($incidentDate) || !in_array($incidentDate, $allowed['dates'], true)
        || !is_string($location) || !in_array($location, $allowed['locations'], true)
        || !is_string($detail)
        || !in_array($detail, $allowed['details'][$category], true)
        || ($person !== null && (!is_string($person) || !in_array($person, $allowed['people'], true)))
        || ($witnesses !== null && (!is_string($witnesses) || !in_array($witnesses, $allowed['witnesses'], true)))
        || !is_bool($urgent)
        || !is_string($submissionToken)
        || !preg_match('/\A[a-f0-9]{32}\z/D', $submissionToken)
        || !is_string($trackingToken)
        || !preg_match('/\A[a-f0-9]{32}\z/D', $trackingToken)) {
        report_error(422, 'One or more report selections are invalid.');
    }

    try {
        $pdo = db();
        $existing = $pdo->prepare(
            'SELECT reference, reporting_method, tracking_token_hash
             FROM reports WHERE submission_token = ? LIMIT 1'
        );
        $existing->execute([$submissionToken]);
        $existingReport = $existing->fetch();
        if ($existingReport) {
            if ($existingReport['reporting_method'] !== ($identified ? 'Identified' : 'Anonymous')) {
                report_error(409, 'Submission token was already used for a different reporting method.');
            }
            if (!is_string($existingReport['tracking_token_hash'])
                || !hash_equals($existingReport['tracking_token_hash'], hash('sha256', $trackingToken))) {
                report_error(409, 'Submission token was already used with a different follow-up code.');
            }
            echo json_encode([
                'success' => true,
                'reference' => $existingReport['reference'],
                'tracking_token' => $trackingToken,
            ]);
            return;
        }

        $studentRef = null;
        $studentName = null;
        if ($identified) {
            $studentRef = filter_var($input['student_ref'] ?? null, FILTER_VALIDATE_INT);
            if ($studentRef === false || $studentRef === null || $studentRef < 1) {
                report_error(422, 'Identified reports require a valid student reference.');
            }
            $studentQuery = $pdo->prepare(
                "SELECT id, full_name, email FROM students WHERE id = ? AND card_status = 'Active' LIMIT 1"
            );
            $studentQuery->execute([$studentRef]);
            $student = $studentQuery->fetch();
            if (!$student) {
                report_error(422, 'The identified student record is no longer active.');
            }
            $studentName = $student['full_name'];
        }

        $pdo->beginTransaction();
        $insert = $pdo->prepare(
            'INSERT INTO reports
             (submission_token, student_ref, reporting_method, category, incident_date, location,
              incident_detail, person_involved, witnesses, immediate_assistance, priority, tracking_token_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insert->execute([
            $submissionToken,
            $studentRef,
            $identified ? 'Identified' : 'Anonymous',
            $category,
            $incidentDate,
            $location,
            $detail,
            $person,
            $witnesses,
            $urgent ? 1 : 0,
            $urgent ? 'High' : 'Normal',
            hash('sha256', $trackingToken),
        ]);
        $id = (int)$pdo->lastInsertId();
        $reference = 'CNHS-' . date('Ymd') . '-' . str_pad((string)$id, 6, '0', STR_PAD_LEFT);
        $update = $pdo->prepare('UPDATE reports SET reference = ? WHERE id = ?');
        $update->execute([$reference, $id]);
        $pdo->commit();
        send_admin_report_email([
            'reference' => $reference,
            'priority' => $urgent ? 'High' : 'Normal',
            'reporting_method' => $identified ? 'Identified' : 'Anonymous',
            'student_name' => $studentName,
            'category' => $category,
            'incident_date' => $incidentDate,
            'location' => $location,
        ]);
        if ($identified && !empty($student['email'])) {
            send_student_report_tracking_email((string)$student['email'], $reference, $trackingToken);
        }
    } catch (Throwable $error) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Report submission failed: ' . $error->getMessage());
        report_error(500, 'The report could not be saved.');
    }

    echo json_encode([
        'success' => true,
        'reference' => $reference,
        'tracking_token' => $trackingToken,
        'priority' => $urgent ? 'High' : 'Normal',
    ]);
}
