<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/scan_cache.php';
require_role('admin');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['success' => false, 'message' => 'Use POST to start a card capture.']);
    exit;
}

verify_csrf();
try {
    $scanId = arm_latest_scan_capture();
    echo json_encode(['success' => true, 'scan_id' => $scanId]);
} catch (Throwable $error) {
    error_log('RFID enrollment capture could not be armed: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not start card capture.']);
}
