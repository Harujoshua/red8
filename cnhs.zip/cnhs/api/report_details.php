<?php
require_once __DIR__ . '/../config.php';
require_role('admin', 'counselor');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid report reference.']);
    exit;
}

$stmt = db()->prepare(
    'SELECT r.id, r.reference, r.priority, r.status, r.reporting_method, r.category,
            r.incident_date, r.location, r.incident_detail, r.person_involved,
            r.witnesses, r.created_at, s.student_id, s.full_name
     FROM reports r
     LEFT JOIN students s ON s.id = r.student_ref
     WHERE r.id = ? LIMIT 1'
);
$stmt->execute([$id]);
$report = $stmt->fetch();
if (!$report) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Report not found.']);
    exit;
}

audit_event('report.details_viewed', 'report', $report['id'], [
    'reference' => $report['reference'],
]);
echo json_encode([
    'success' => true,
    'report' => [
        'reference' => $report['reference'],
        'priority' => $report['priority'],
        'status' => $report['status'],
        'method' => $report['reporting_method'],
        'student' => $report['reporting_method'] === 'Anonymous'
            ? 'Anonymous'
            : trim((string)$report['student_id'] . ' ' . (string)$report['full_name']),
        'category' => $report['category'],
        'date' => $report['incident_date'],
        'location' => $report['location'],
        'detail' => $report['incident_detail'],
        'person' => $report['person_involved'] ?? 'Skipped',
        'witnesses' => $report['witnesses'] ?? 'Skipped',
        'submitted' => $report['created_at'],
    ],
]);
