<?php
require_once 'config.php';
require_role('admin');
$totalStudents=(int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn();
$perPage=20;
$requestedPage=filter_var($_GET['page']??1,FILTER_VALIDATE_INT);
$currentPage=is_int($requestedPage)&&$requestedPage>0?$requestedPage:1;
$totalPages=max(1,(int)ceil($totalStudents/$perPage));
$currentPage=min($currentPage,$totalPages);
$offset=($currentPage-1)*$perPage;
$students=db()->query(
    'SELECT student_id,full_name,year_level,rfid_uid,card_status,created_at
     FROM students
     ORDER BY created_at DESC
     LIMIT '.$perPage.' OFFSET '.$offset
)->fetchAll();
$rangeStart=$totalStudents===0?0:$offset+1;
$rangeEnd=min($offset+$perPage,$totalStudents);
$paginationUrl=static fn(int $page):string=>'activity.php?page='.$page;
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Recently Added Students</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head><body>
<?php include 'nav.php'; ?><main class="container activity-page">
<section class="panel"><div class="section-head"><h2>Recently added students</h2><span class="pill blue"><?=$totalStudents?> total</span></div><div class="table-wrap"><table><thead><tr><th>Student ID</th><th>Full name</th><th>Grade level</th><th>RFID UID</th><th>Status</th><th>Added</th></tr></thead><tbody>
<?php foreach($students as $student): ?><tr><td><?=h($student['student_id'])?></td><td><?=h($student['full_name'])?></td><td><?=h($student['year_level'])?></td><td><code><?=h($student['rfid_uid']?:'Not assigned')?></code></td><td><span class="pill <?=$student['card_status']==='Active'?'green':'gray'?>"><?=h($student['card_status'])?></span></td><td><?=h($student['created_at'])?></td></tr><?php endforeach; ?>
<?php if(!$students): ?><tr><td colspan="6" class="empty">No students registered yet.</td></tr><?php endif; ?>
</tbody></table></div>
<nav class="pagination activity-pagination" aria-label="Recent activity pages">
  <span class="pagination-summary">Showing <?=$rangeStart?>–<?=$rangeEnd?> of <?=$totalStudents?></span>
  <div class="pagination-links">
    <?php if($currentPage>1): ?><a href="<?=h($paginationUrl($currentPage-1))?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</a><?php else: ?><span class="disabled"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i> Previous</span><?php endif; ?>
    <?php
      $firstPage=max(1,$currentPage-2);
      $lastPage=min($totalPages,$currentPage+2);
      if($firstPage>1): ?><a href="<?=h($paginationUrl(1))?>">1</a><?php if($firstPage>2): ?><span class="pagination-ellipsis">…</span><?php endif; ?><?php endif;
      for($pageNumber=$firstPage;$pageNumber<=$lastPage;$pageNumber++):
        if($pageNumber===$currentPage): ?><span class="current" aria-current="page"><?=$pageNumber?></span><?php else: ?><a href="<?=h($paginationUrl($pageNumber))?>"><?=$pageNumber?></a><?php endif;
      endfor;
      if($lastPage<$totalPages): if($lastPage<$totalPages-1): ?><span class="pagination-ellipsis">…</span><?php endif; ?><a href="<?=h($paginationUrl($totalPages))?>"><?=$totalPages?></a><?php endif;
    ?>
    <?php if($currentPage<$totalPages): ?><a href="<?=h($paginationUrl($currentPage+1))?>" aria-label="Next page">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a><?php else: ?><span class="disabled">Next <i class="fa-solid fa-chevron-right" aria-hidden="true"></i></span><?php endif; ?>
  </div>
</nav></section>
</main></body></html>
