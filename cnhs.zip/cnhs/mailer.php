<?php
require_once __DIR__.'/config.php';
if(is_file(__DIR__.'/vendor/autoload.php')){
    require_once __DIR__.'/vendor/autoload.php';
}

function send_admin_report_email(array $report): bool {
    if(!class_exists(\PHPMailer\PHPMailer\PHPMailer::class)){
        error_log('Admin report email not sent: install project dependencies with Composer.');
        return false;
    }
    if(MAIL_HOST==='' || MAIL_USERNAME==='' || MAIL_PASSWORD==='' || MAIL_FROM===''){
        error_log('Admin report email not sent: SMTP settings are incomplete.');
        return false;
    }

    $stmt=db()->query("SELECT email FROM admins WHERE is_active = 1 AND email IS NOT NULL AND email <> ''");
    $emails=$stmt->fetchAll();
    if(!$emails){
        error_log('Admin report email not sent: no admin email address is configured.');
        return false;
    }

    $reference=(string)($report['reference'] ?? '');
    $priority=(string)($report['priority'] ?? 'Normal');
    $subject='['.$priority.' Priority] New CNHS report '.$reference;
    $body="A new student report has been submitted.\n\n"
        ."Reference: {$reference}\n"
        ."Priority: {$priority}\n"
        ."Reporting method: ".($report['reporting_method'] ?? '')."\n";
    if(($report['reporting_method'] ?? '')==='Identified' && !empty($report['student_name'])){
        $studentName=str_replace(["\r","\n"],' ',trim((string)$report['student_name']));
        $body.="Student: {$studentName}\n";
    }
    $body.="Category: ".($report['category'] ?? '')."\n"
        ."Incident date: ".($report['incident_date'] ?? '')."\n"
        ."Location: ".($report['location'] ?? '')."\n"
        ."Submitted: ".date('Y-m-d H:i:s')."\n\n"
        ."Open the Reports module to review the report.";

    if(!in_array(MAIL_ENCRYPTION,['tls','ssl','none'],true)){
        error_log('Admin report email not sent: unsupported SMTP encryption setting.');
        return false;
    }
    $mail=new \PHPMailer\PHPMailer\PHPMailer(true);
    try{
        $mail->isSMTP();
        $mail->Host=MAIL_HOST;
        $mail->Port=MAIL_PORT;
        $mail->SMTPAuth=true;
        $mail->Username=MAIL_USERNAME;
        $mail->Password=MAIL_PASSWORD;
        if(MAIL_ENCRYPTION==='ssl'){
            $mail->SMTPSecure=\PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        }elseif(MAIL_ENCRYPTION==='tls'){
            $mail->SMTPSecure=\PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->CharSet=\PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
        $mail->setFrom(MAIL_FROM,MAIL_FROM_NAME);
        $mail->Subject=$subject;
        $mail->Body=$body;
        $mail->isHTML(false);
    }catch(\PHPMailer\PHPMailer\Exception $error){
        error_log('Admin report email configuration failed: '.$mail->ErrorInfo);
        return false;
    }
    $sent=true;
    foreach($emails as $row){
        $email=trim((string)($row['email']??''));
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            error_log('Admin report email not sent: an admin email address is invalid.');
            $sent=false;
            continue;
        }
        try{
            $mail->clearAllRecipients();
            $mail->addAddress($email);
            $mail->send();
        }catch(\PHPMailer\PHPMailer\Exception $error){
            error_log('Admin report email delivery failed: '.$mail->ErrorInfo);
            $sent=false;
        }
    }
    return $sent;
}

function send_student_report_tracking_email(string $email, string $reference, string $token): bool {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)
        || !class_exists(\PHPMailer\PHPMailer\PHPMailer::class)
        || MAIL_HOST === '' || MAIL_USERNAME === '' || MAIL_PASSWORD === '' || MAIL_FROM === '') {
        error_log('Student report follow-up email not sent: recipient or SMTP configuration is unavailable.');
        return false;
    }

    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = MAIL_HOST;
        $mail->Port = MAIL_PORT;
        $mail->SMTPAuth = true;
        $mail->Username = MAIL_USERNAME;
        $mail->Password = MAIL_PASSWORD;
        if (MAIL_ENCRYPTION === 'ssl') {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif (MAIL_ENCRYPTION === 'tls') {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } elseif (MAIL_ENCRYPTION !== 'none') {
            error_log('Student report follow-up email not sent: unsupported SMTP encryption setting.');
            return false;
        }
        $mail->CharSet = \PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($email);
        $mail->Subject = 'Your CNHS report follow-up code';
        $mail->Body = "Your report was submitted successfully.\n\n"
            . "Reference: {$reference}\n"
            . "Follow-up code: {$token}\n\n"
            . "Keep this code private. Use it with your reference at report.php to check its status, or sign in to your approved student portal account to view identified concerns.";
        $mail->isHTML(false);
        $mail->send();
        return true;
    } catch (\PHPMailer\PHPMailer\Exception $error) {
        error_log('Student report follow-up email delivery failed: ' . $mail->ErrorInfo);
        return false;
    }
}
